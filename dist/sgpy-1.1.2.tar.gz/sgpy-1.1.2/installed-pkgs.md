Install GConf2 3.2.6-2 (automatically added)
Install GeoIP 1.6.9-1
Install GeoIP-database 20180505-1
Install GeoIP-debuginfo 1.6.9-1
Install ImageMagick 6.9.10.11-1 (automatically added)
Install OpenSP 1.5.2-2 (automatically added)
Install WordNet 3.0-4
Install XmHTML 1.1.7-13
Install _autorebase 001007-1
Install abiword 3.0.2-3
Install abiword-docs 3.0.1-1
Install abiword-plugins 3.0.2-3
Install adwaita-icon-theme 3.26.1-1 (automatically added)
Install alacarte 3.11.91-1 (automatically added)
Install alternatives 1.3.30c-10
Install anjuta 3.26.0-1
Install antiword 0.37-1
Install archivemail 0.9.0-1
Install aria2 1.32.0-1
Install arj 3.10.22-3 (automatically added)
Install arts 1.5.10-4
Install ascii 3.15-1
Install aspell-ar 1.2.0-1
Install aspell-en 2017.08.24.0-1
Install asymptote 2.49-1
Install at-spi2-core 2.26.2-1 (automatically added)
Install attr 2.4.48-2
Install attr-src 2.4.48-2 (source)
Install audacity 2.2.1-1
Install autobuild 5.3-1
Install autoconf 13-1
Install autoconf-archive 2017.09.28-1
Install autoconf2.1 2.13-12 (automatically added)
Install autoconf2.5 2.69-4
Install autogen 5.18.16-1
Install automake 10-1 (automatically added)
Install automake1.10 1.10.3-3 (automatically added)
Install automake1.11 1.11.6-3 (automatically added)
Install automake1.12 1.12.6-3 (automatically added)
Install automake1.13 1.13.4-2 (automatically added)
Install automake1.14 1.14.1-3 (automatically added)
Install automake1.15 1.15.1-1
Install automake1.9 1.9.6-11 (automatically added)
Install autossh 1.4g-1
Install base-cygwin 3.8-1
Install base-files 4.3-2
Install bash 4.4.12-3
Install biber 2.12-1 (automatically added)
Install bind 9.11.6-1
Install bind-utils 9.11.6-1
Install binutils 2.29-1 (automatically added)
Install build-docbook-catalog 1.5-2 (automatically added)
Install bzip2 1.0.6-3
Install bzr 2.7.0+bzr6622-1
Install ca-certificates 2.30-1
Install cadaver 0.23.3-1
Install cadaver-src 0.23.3-1 (source)
Install calf-common 0.0.18.6-1
Install calligra-data 3.1.0-1
Install calligra-libs 3.1.0-1
Install calligra-sheets 3.1.0-1
Install calligra-tools 3.1.0-1
Install catdoc 0.95-1 (automatically added)
Install cfget 0.18-1
Install checkbashisms 2.17.10-1
Install chewmail 1.2-1
Install code2html 0.9.1-1
Install codeville 0.8.0-4
Install colorgcc 1.3.2-2
Install convmv 1.12-1
Install copyright-update 2015.0928+git20e4e0e-1
Install coreutils 8.26-2
Install cpio 2.11-3 (automatically added)
Install cron 4.1-65
Install cron-src 4.1-65 (source)
Install crypt 2.1-1 (automatically added)
Install crypto-policies 20190218-1
Install csih 0.9.11-1 (automatically added)
Install curl 7.65.0-1
Install curl-debuginfo 7.65.0-1
Install cvs 1.11.23-2
Install cygport 0.33.1-1
Install cygrunsrv 1.62-1 (automatically added)
Install cygutils 1.4.16-2
Install cygutils-extra 1.4.16-2 (automatically added)
Install cygwin 3.0.7-1
Install cygwin-debuginfo 3.0.7-1 (automatically added)
Install cygwin-devel 3.0.7-1 (automatically added)
Install dash 0.5.9.1-1
Install dblatex 0.3.10-1 (automatically added)
Install dbus 1.10.22-1 (automatically added)
Install dconf-service 0.26.1-1 (automatically added)
Install ddd 3.3.12-3
Install ddir 2010.0321+git1685e72-1
Install dejavu-fonts 2.37-1 (automatically added)
Install delta 2006.08.03-1
Install desktop-file-utils 0.23-1 (automatically added)
Install devhelp-common 3.8.2-3 (automatically added)
Install dialog 1.3-3.20170131 (automatically added)
Install diffstat 1.61-1
Install diffutils 3.5-2
Install docbook-xml43 4.3-2 (automatically added)
Install docbook-xml45 4.5-1 (automatically added)
Install docbook-xsl 1.77.1-1 (automatically added)
Install docbook2X 0.8.8-1
Install dos2unix 7.4.0-1 (automatically added)
Install dri-drivers 18.0.5-1 (automatically added)
Install easytag 2.4.3-1
Install ed 1.15-1 (automatically added)
Install editrights 1.03-1
Install email 3.2.3-git-2
Install email-debuginfo 3.2.3-git-2
Install enca 1.18-1
Install esound 0.2.41-12
Install espeak 1.47.11-1
Install evolution-data-server 3.20.6-3 (automatically added)
Install exim 4.86-1
Install extractpdfmark 1.0.2-1
Install fcgi 2.4.0-3
Install fdkaac 0.6.3-1
Install figlet 2.2.2-2
Install file 5.32-1
Install filezilla 3.27.0-1
Install findutils 4.6.0-1
Install flac 1.3.2-1
Install flac-docs 1.3.2-1
Install flip 1.19-1
Install fluidsynth 1.1.10-1
Install fluidsynth-src 1.1.10-1 (source)
Install font-bh-lucidatypewriter-dpi75 7.5-3 (automatically added)
Install freerdp 2.0.0-0.6.rc2
Install gamin 0.1.10-15 (automatically added)
Install gawk 5.0.0-1
Install gcc-core 7.4.0-1 (automatically added)
Install gcc-g++ 7.4.0-1 (automatically added)
Install gconf-desktop-schemas 2.32.1-3 (automatically added)
Install gcr 3.20.0-1 (automatically added)
Install gdb 8.1.1-1
Install gdk-pixbuf2.0-svg 2.40.20-1 (automatically added)
Install geoipupdate 2.2.2-1
Install getent 2.18.90-4
Install getmail 5.1-1
Install gettext 0.19.8.1-2
Install gettext-devel 0.19.8.1-2
Install ghostscript 9.27-1 (automatically added)
Install ghostscript-fonts-other 6.0-1 (automatically added)
Install girepository-Anjuta3.0 3.26.0-1 (automatically added)
Install girepository-Atk1.0 2.26.1-1 (automatically added)
Install girepository-Clutter1.0 1.26.2-1 (automatically added)
Install girepository-ClutterGst3.0 3.0.24-1 (automatically added)
Install girepository-Cogl1.0 1.22.2-1 (automatically added)
Install girepository-GIRepository2.0 1.54.1-1 (automatically added)
Install girepository-GLib2.0 1.54.1-1 (automatically added)
Install girepository-GMenu3.0 3.13.3-3 (automatically added)
Install girepository-GdkPixbuf2.0 2.36.11-1 (automatically added)
Install girepository-Gdl3 3.26.0-1 (automatically added)
Install girepository-Gee0.8 0.20.1-1 (automatically added)
Install girepository-Ggit1.0 0.26.2-1 (automatically added)
Install girepository-Gst1.0 1.12.5-1 (automatically added)
Install girepository-GstInterfaces1.0 1.12.5-1 (automatically added)
Install girepository-Gtk2.0 2.24.32-1 (automatically added)
Install girepository-Gtk3.0 3.22.28-1 (automatically added)
Install girepository-GtkClutter1.0 1.8.4-1 (automatically added)
Install girepository-GtkSource3.0 3.24.6-1 (automatically added)
Install girepository-HarfBuzz0.0 1.7.6-1 (automatically added)
Install girepository-Json1.0 1.4.2-1 (automatically added)
Install girepository-Pango1.0 1.40.14-1 (automatically added)
Install girepository-Poppler0.18 0.62.0-1 (automatically added)
Install girepository-Rsvg2.0 2.40.20-1 (automatically added)
Install girepository-Soup2.4 2.60.3-1 (automatically added)
Install girepository-Vte2.91 0.50.2-1 (automatically added)
Install girepository-WebKit1.0 2.0.4-5 (automatically added)
Install girepository-WebKit3.0 2.0.4-5 (automatically added)
Install girepository-cairo1.0 1.54.1-1 (automatically added)
Install girepository-msi0 0.97-1
Install girepository-x11 1.54.1-1 (automatically added)
Install git 2.17.0-1
Install git-archive-all 1.19.4-1
Install git-debuginfo 2.21.0-1
Install git-email 2.17.0-1
Install git-gui 2.21.0-1
Install gitg 3.26.0-1
Install gitk 2.21.0-1
Install gitweb 2.17.0-1
Install glabels 3.4.0-1
Install glade 3.20.3-1
Install glade-xapp 1.0.4-1
Install glade3 3.8.6-1
Install glade3-gnome 3.8.6-1
Install glib2.0-networking 2.54.1-1 (automatically added)
Install gmp 6.1.2-1 (automatically added)
Install gmpc 11.8.16-3
Install gmpc-libnotify 11.8.16-2
Install gnome-applets 3.26.0-1
Install gnome-dictionary 3.26.1-1 (automatically added)
Install gnome-directory-thumbnailer 0.1.10-1
Install gnome-exe-thumbnailer 0.9.3-1
Install gnome-exe-thumbnailer-src 0.9.3-1 (source)
Install gnome-keyring 3.20.1-1 (automatically added)
Install gnome-menus 3.13.3-3 (automatically added)
Install gnome-mime-data 2.18.0-10 (automatically added)
Install gnome-online-accounts 3.22.6-2 (automatically added)
Install gnome-online-accounts-debuginfo 3.22.6-2
Install gnome-panel 3.26.0-1 (automatically added)
Install gnome-python 2.28.1-3
Install gnome-ssh-askpass 7.4-1
Install gnome-ssh-askpass-debuginfo 7.4-1
Install gnome-sudoku-debuginfo 3.26.0-1
Install gnucash 2.6.21-1
Install gnupg 1.4.23-1 (automatically added)
Install gq 1.3.4-3
Install grep 3.0-2
Install grepmail 5.3033-3
Install groff 1.22.4-1
Install groff-X11 1.22.4-1
Install groff-perl 1.22.4-1
Install gsettings-desktop-schemas 3.24.1-1 (automatically added)
Install gst123 0.3.4-1
Install gstreamer1.0 1.12.5-1
Install gstreamer1.0-plugins-base 1.12.5-1
Install gstreamer1.0-plugins-espeak 0.4.0-1
Install gstreamer1.0-plugins-good 1.12.5-1
Install gstreamer1.0-plugins-good-extras 1.12.5-1
Install gstreamer1.0-rtsp-server 1.12.5-1
Install gtk-doc 1.26-1 (automatically added)
Install gtk-update-icon-cache 3.22.28-1 (automatically added)
Install gtypist 2.9.3-1
Install guile1.8 1.8.8-3 (automatically added)
Install gv 3.7.4-1
Install gzip 1.8-1
Install haxe 3.4.7-1
Install help2man 1.47.4-1
Install hicolor-icon-theme 0.15-1 (automatically added)
Install highlight 3.50-1
Install highlight-common 3.50-1
Install highlight-gui 3.50-1
Install homebank 5.1.8-1
Install hostname 3.13-1
Install html2ps 1.0b7-2
Install htmldoc 1.8.28-3
Install htmldoc-debuginfo 1.8.28-3
Install httpd 2.4.39-1 (automatically added)
Install httpd-mod_php7 7.3.4-1
Install httpie 1.0.2-1
Install hunspell 1.6.1-1
Install hyphen-en 2.8.8-1 (automatically added)
Install icon-naming-utils 0.8.90-1 (automatically added)
Install icoutils 0.32.3-1 (automatically added)
Install idle37 3.7.3-1
Install inetutils 1.9.4-1
Install inetutils-server 1.9.4-1
Install info 6.6-1
Install intltool 0.51.0-1
Install ipc-utils 1.0-2
Install ipcalc 0.41-1
Install iso-codes 3.75-1
Install itstool 2.0.2-1
Install jgraph 8.4-1
Install jpeg 1.5.3-1 (automatically added)
Install jq 1.6-1
Install jsc3 2.0.4-5 (automatically added)
Install karbon 3.1.0-1
Install kasumi 2.5-2
Install kf5-kdoctools 5.43.0-1 (automatically added)
Install kmymoney 5.0.1-1
Install ksshaskpass 5.8.9-1
Install ksystemlog 17.12.3-1
Install ksystemlog-src 17.12.3-1 (source)
Install latexila 3.26.1-1
Install less 530-1
Install lftp 4.8.4-1 (automatically added)
Install libAiksaurus1.2_0 1.2.1-11 (automatically added)
Install libEGL1 18.0.5-1 (automatically added)
Install libEMF1 1.0.9-1 (automatically added)
Install libFLAC++6 1.3.2-1 (automatically added)
Install libFLAC8 1.3.2-1 (automatically added)
Install libGL1 18.0.5-1 (automatically added)
Install libGLU1 9.0.0-1 (automatically added)
Install libGeoIP1 1.6.9-1 (automatically added)
Install libICE6 1.0.9-1 (automatically added)
Install libIDL2_0 0.8.14-2 (automatically added)
Install libJudy1 1.0.5-1 (automatically added)
Install libKChart2 2.6.0-1 (automatically added)
Install libKF5Activities5 5.43.0-1 (automatically added)
Install libKF5Akonadi5 17.12.3-1 (automatically added)
Install libKF5Archive5 5.43.0-1 (automatically added)
Install libKF5Attica5 5.43.0-1 (automatically added)
Install libKF5Auth5 5.43.0-1 (automatically added)
Install libKF5Bookmarks5 5.43.0-1 (automatically added)
Install libKF5Codecs5 5.43.0-1 (automatically added)
Install libKF5Completion5 5.43.0-1 (automatically added)
Install libKF5Config5 5.43.0-1 (automatically added)
Install libKF5ConfigWidgets5 5.43.0-1 (automatically added)
Install libKF5Contacts5 17.12.3-1 (automatically added)
Install libKF5CoreAddons5 5.43.0-1 (automatically added)
Install libKF5Crash5 5.43.0-1 (automatically added)
Install libKF5DBusAddons5 5.43.0-1 (automatically added)
Install libKF5Declarative5 5.43.0-1 (automatically added)
Install libKF5Emoticons5 5.43.0-1 (automatically added)
Install libKF5GlobalAccel5 5.43.0-1 (automatically added)
Install libKF5GuiAddons5 5.43.0-1 (automatically added)
Install libKF5Holidays5 17.12.3-1 (automatically added)
Install libKF5I18n5 5.43.0-1 (automatically added)
Install libKF5IconThemes5 5.43.0-1 (automatically added)
Install libKF5IdentityManagement5 17.12.3-1 (automatically added)
Install libKF5ItemModels5 5.43.0-1 (automatically added)
Install libKF5ItemViews5 5.43.0-1 (automatically added)
Install libKF5JS5 5.43.0-1 (automatically added)
Install libKF5JobWidgets5 5.43.0-1 (automatically added)
Install libKF5KCMUtils5 5.43.0-1 (automatically added)
Install libKF5KDELibs4Support5 5.43.0-1 (automatically added)
Install libKF5KHtml5 5.43.0-2 (automatically added)
Install libKF5KIO5 5.43.0-1 (automatically added)
Install libKF5Notifications5 5.43.0-1 (automatically added)
Install libKF5NotifyConfig5 5.43.0-1 (automatically added)
Install libKF5Package5 5.43.0-1 (automatically added)
Install libKF5Parts5 5.43.0-1 (automatically added)
Install libKF5PimTextEdit5 17.12.3-1 (automatically added)
Install libKF5Service5 5.43.0-1 (automatically added)
Install libKF5Solid5 5.43.0-1 (automatically added)
Install libKF5Sonnet5 5.43.0-1 (automatically added)
Install libKF5SyntaxHighlighting5 5.43.0-1 (automatically added)
Install libKF5TextWidgets5 5.43.0-1 (automatically added)
Install libKF5Wallet5 5.43.0-1 (automatically added)
Install libKF5WebKit5 5.43.0-1 (automatically added)
Install libKF5WidgetsAddons5 5.43.0-1 (automatically added)
Install libKF5WindowSystem5 5.43.0-1 (automatically added)
Install libKF5XmlGui5 5.43.0-1 (automatically added)
Install libLASi1 1.1.1-2 (automatically added)
Install libMagickC++6_8 6.9.10.11-1 (automatically added)
Install libMagickCore6_6 6.9.10.11-1 (automatically added)
Install libMagickWand6_6 6.9.10.11-1 (automatically added)
Install libORBit2_0 2.14.19-2 (automatically added)
Install libQt5Core5 5.9.4-2 (automatically added)
Install libQt5Gui5 5.9.4-2 (automatically added)
Install libQt5Positioning5 5.9.4-2 (automatically added)
Install libQt5Quick5 5.9.4-1 (automatically added)
Install libQt5Script5 5.9.4-1 (automatically added)
Install libQt5Sql5 5.9.4-2 (automatically added)
Install libQt5Svg5 5.9.4-1 (automatically added)
Install libQt5TextToSpeech5 5.9.4-1 (automatically added)
Install libQt5WebChannel5 5.9.4-1 (automatically added)
Install libQt5WebKit5 5.9.3-0.3.20180115git (automatically added)
Install libQt5X11Extras5 5.9.4-1 (automatically added)
Install libQt5XmlPatterns5 5.9.4-1 (automatically added)
Install libQtCore4 4.8.7-4 (automatically added)
Install libQtGui4 4.8.7-4 (automatically added)
Install libQtNetwork4 4.8.7-4 (automatically added)
Install libQtSvg4 4.8.7-4 (automatically added)
Install libQtXml4 4.8.7-4 (automatically added)
Install libSDL2_2.0_0 2.0.7-1 (automatically added)
Install libSM6 1.2.2-1 (automatically added)
Install libSoundTouch1 2.0.0-1 (automatically added)
Install libX11-devel 1.6.5-1 (automatically added)
Install libX11-xcb1 1.6.5-1 (automatically added)
Install libX11_6 1.6.5-1 (automatically added)
Install libXRes1 1.2.0-1 (automatically added)
Install libXau-devel 1.0.8-1 (automatically added)
Install libXau6 1.0.8-1 (automatically added)
Install libXaw3d8 1.6.2-2 (automatically added)
Install libXaw7 1.0.13-1 (automatically added)
Install libXcomposite1 0.4.3-1 (automatically added)
Install libXcursor1 1.1.15-1 (automatically added)
Install libXdamage1 1.1.4-1 (automatically added)
Install libXdmcp-devel 1.1.2-1 (automatically added)
Install libXdmcp6 1.1.2-1 (automatically added)
Install libXext-devel 1.3.3-1 (automatically added)
Install libXext6 1.3.3-1 (automatically added)
Install libXfixes3 5.0.3-1 (automatically added)
Install libXft-devel 2.3.2-1 (automatically added)
Install libXft2 2.3.2-1 (automatically added)
Install libXi6 1.7.9-1 (automatically added)
Install libXinerama1 1.1.3-1 (automatically added)
Install libXm4 2.3.6-1 (automatically added)
Install libXmHTML0 1.1.7-13 (automatically added)
Install libXmu6 1.1.2-1 (automatically added)
Install libXpm4 3.5.12-1 (automatically added)
Install libXrandr2 1.5.1-1 (automatically added)
Install libXrender-devel 0.9.9-1 (automatically added)
Install libXrender1 0.9.9-1 (automatically added)
Install libXss1 1.2.2-1 (automatically added)
Install libXt6 1.1.5-1 (automatically added)
Install libXtst6 1.2.3-1 (automatically added)
Install libaa1 1.4rc5-12 (automatically added)
Install libabiword3.0 3.0.2-3 (automatically added)
Install libabw-tools 0.1.2-1 (automatically added)
Install libabw0.1_1 0.1.2-1 (automatically added)
Install libalkimia5_7 7.0-1 (automatically added)
Install libanjuta3_0 3.26.0-1 (automatically added)
Install libanthy-common 9100h-2 (automatically added)
Install libanthy0 9100h-2 (automatically added)
Install libapr1 1.6.5-1 (automatically added)
Install libaprutil1 1.6.1-1 (automatically added)
Install libaqbanking-common 5.7.8-1 (automatically added)
Install libaqbanking35 5.7.8-1 (automatically added)
Install libaqebics0 5.7.8-1 (automatically added)
Install libaqhbci24 5.7.8-1 (automatically added)
Install libaqofxconnect7 5.7.8-1 (automatically added)
Install libaqpaypal0 5.7.8-1 (automatically added)
Install libargon2_1 20171227-1 (automatically added)
Install libargp 20110921-3
Install libart_lgpl_2_2 2.3.21-2 (automatically added)
Install libarts1 1.5.10-4 (automatically added)
Install libartsc0 1.5.10-4 (automatically added)
Install libaspell15 0.60.6.1-1 (automatically added)
Install libassuan0 2.5.3-1 (automatically added)
Install libasyncns0 0.8-1 (automatically added)
Install libatk-bridge2.0_0 2.26.1-1 (automatically added)
Install libatk1.0-devel 2.26.1-1 (automatically added)
Install libatk1.0_0 2.26.1-1 (automatically added)
Install libatkmm1.6_1 2.24.2-1 (automatically added)
Install libatomic1 7.4.0-1 (automatically added)
Install libatspi0 2.26.2-1 (automatically added)
Install libattr1 2.4.48-2
Install libattr1-src 2.4.48-2 (source)
Install libaudio2 1.9.3-1 (automatically added)
Install libaudiofile1 0.3.6-2 (automatically added)
Install libautotrace3 0.31.1-19 (automatically added)
Install libavahi-client3 0.7-1 (automatically added)
Install libavahi-common3 0.7-1 (automatically added)
Install libavahi-glib1 0.7-1 (automatically added)
Install libayatana-appindicator-common 0.5.3-1 (automatically added)
Install libayatana-appindicator1 0.5.3-1 (automatically added)
Install libayatana-appindicator3_1 0.5.3-1 (automatically added)
Install libayatana-indicator-common 0.6.2-1 (automatically added)
Install libayatana-indicator3_7 0.6.2-1 (automatically added)
Install libayatana-indicator7 0.6.2-1 (automatically added)
Install libbind9_161 9.11.6-1 (automatically added)
Install libblkid1 2.33.1-1
Install libbonobo2_0 2.32.1-2 (automatically added)
Install libbonoboui2_0 2.24.5-2 (automatically added)
Install libboost_locale1.66 1.66.0-1 (automatically added)
Install libboost_program_options1.66 1.66.0-1 (automatically added)
Install libboost_regex1.66 1.66.0-1 (automatically added)
Install libboost_system1.66 1.66.0-1 (automatically added)
Install libboost_thread1.66 1.66.0-1 (automatically added)
Install libbotan1.10_1 1.10.17-2 (automatically added)
Install libbrotlicommon1 1.0.7-1 (automatically added)
Install libbrotlidec1 1.0.7-1 (automatically added)
Install libbz2-devel 1.0.6-3 (automatically added)
Install libbz2_1 1.0.6-3
Install libcaca0 0.99.beta19-4 (automatically added)
Install libcairo-devel 1.14.12-1 (automatically added)
Install libcairo2 1.14.12-1 (automatically added)
Install libcairomm1.0_1 1.12.0-1 (automatically added)
Install libcamel1.2_57 3.20.6-3 (automatically added)
Install libcanberra-gtk3_0 0.30-1 (automatically added)
Install libcanberra0 0.30-1 (automatically added)
Install libcares2 1.14.0-1 (automatically added)
Install libcdio18 2.0.0-1 (automatically added)
Install libcdio_cdda2 10.2+0.94+2-1 (automatically added)
Install libcdio_paranoia2 10.2+0.94+2-1 (automatically added)
Install libcdr-tools 0.1.4-2 (automatically added)
Install libcdr0.1_1 0.1.4-2 (automatically added)
Install libcdt5 2.40.1-4 (automatically added)
Install libcfitsio3 3.360-1 (automatically added)
Install libcgraph6 2.40.1-4 (automatically added)
Install libchamplain-gtk0.12_0 0.12.16-1 (automatically added)
Install libchamplain0.12_0 0.12.16-1 (automatically added)
Install libcharset1 1.14-3 (automatically added)
Install libchm0 0.40-1 (automatically added)
Install libclang5.0 5.0.1-2 (automatically added)
Install libclutter-gst3.0_0 3.0.24-1 (automatically added)
Install libclutter-gtk1.0_0 1.8.4-1 (automatically added)
Install libclutter1.0_0 1.26.2-1 (automatically added)
Install libcogl-common 1.22.2-1 (automatically added)
Install libcogl20 1.22.2-1 (automatically added)
Install libcom_err2 1.44.5-1 (automatically added)
Install libcroco0.6 0.6.12-1
Install libcroco0.6_3 0.6.12-1 (automatically added)
Install libcrypt-devel 4.4.4-1 (automatically added)
Install libcrypt0 2.1-1 (automatically added)
Install libcrypt2 4.4.4-1 (automatically added)
Install libct4 1.00.37-1 (automatically added)
Install libcurl-doc 7.65.0-1
Install libcurl4 7.65.0-1
Install libdatrie1 0.2.8-1 (automatically added)
Install libdb5.3 5.3.28-2 (automatically added)
Install libdbi-drivers 0.9.0-1 (automatically added)
Install libdbi1 0.9.0-1 (automatically added)
Install libdbus-glib_1_2 0.108-1 (automatically added)
Install libdbus1_3 1.10.22-1 (automatically added)
Install libdbusmenu-common 16.04.0-1 (automatically added)
Install libdbusmenu-glib4 16.04.0-1 (automatically added)
Install libdbusmenu-gtk3_4 16.04.0-1 (automatically added)
Install libdbusmenu-gtk4 16.04.0-1 (automatically added)
Install libdbusmenu-qt5_2 0.9.3-0.2.20150604bzr (automatically added)
Install libdconf1 0.26.1-1 (automatically added)
Install libdevhelp3_2 3.8.2-3 (automatically added)
Install libdialog14 1.3-3.20170131 (automatically added)
Install libdns1105 9.11.6-1 (automatically added)
Install libdotconf0 1.3-1 (automatically added)
Install libdv4 1.0.0-11 (automatically added)
Install libe-book-tools 0.1.3-2 (automatically added)
Install libe-book0.1_1 0.1.3-2 (automatically added)
Install libebackend1.2_10 3.20.6-3 (automatically added)
Install libebook-contacts1.2_2 3.20.6-3 (automatically added)
Install libebook1.2_16 3.20.6-3 (automatically added)
Install libecal1.2_19 3.20.6-3 (automatically added)
Install libedata-book1.2_25 3.20.6-3 (automatically added)
Install libedata-cal1.2_28 3.20.6-3 (automatically added)
Install libedataserver1.2_21 3.20.6-3 (automatically added)
Install libedit0 20130712-1 (automatically added)
Install libenca0 1.18-1 (automatically added)
Install libenchant1 1.6.1-1 (automatically added)
Install libeot0 0.01-1 (automatically added)
Install libepoxy0 1.4.3-1 (automatically added)
Install libepubgen0.1_1 0.1.0-1 (automatically added)
Install libesd0 0.2.41-12 (automatically added)
Install libespeak1 1.47.11-1 (automatically added)
Install libetonyek-tools 0.1.7-1 (automatically added)
Install libetonyek0.1_1 0.1.7-1 (automatically added)
Install libevent2.0_5 2.0.22-1 (automatically added)
Install libevtlog0 0.2.12-2 (automatically added)
Install libexpat-devel 2.2.6-1 (automatically added)
Install libexpat1 2.2.6-1 (automatically added)
Install libfam0 0.1.10-15 (automatically added)
Install libfcgi0 2.4.0-3 (automatically added)
Install libfdisk1 2.33.1-1
Install libfdk-aac1 0.1.5-2 (automatically added)
Install libffi-devel 3.2.1-2 (automatically added)
Install libffi6 3.2.1-2
Install libfftw3_3 3.3.8-1 (automatically added)
Install libfilezilla0 0.10.0-1 (automatically added)
Install libflite1 1.4-1 (automatically added)
Install libfltk1.3 1.3.4-1 (automatically added)
Install libfluidsynth1 1.1.10-1 (automatically added)
Install libfontconfig-common 2.12.6-1 (automatically added)
Install libfontconfig-devel 2.12.6-1 (automatically added)
Install libfontconfig1 2.12.6-1 (automatically added)
Install libfpx1 1.3.1.4-1 (automatically added)
Install libfreehand-tools 0.1.2-1 (automatically added)
Install libfreehand0.1_1 0.1.2-1 (automatically added)
Install libfreerdp1.0 1.0.2-1
Install libfreerdp2_2 2.0.0-0.6.rc2 (automatically added)
Install libfreetype-devel 2.8.1-1 (automatically added)
Install libfreetype6 2.8.1-1 (automatically added)
Install libfribidi0 0.19.7-1 (automatically added)
Install libgailutil18 2.24.32-1 (automatically added)
Install libgailutil3_0 3.22.28-1 (automatically added)
Install libgc1 8.0.4-1 (automatically added)
Install libgcc1 7.4.0-1
Install libgck1_0 3.20.0-1 (automatically added)
Install libgconf2_4 3.2.6-2 (automatically added)
Install libgconfmm2.6_1 2.28.2-2 (automatically added)
Install libgcr-base3_1 3.20.0-1 (automatically added)
Install libgcr-ui3-common 3.20.0-1 (automatically added)
Install libgcr-ui3_1 3.20.0-1 (automatically added)
Install libgcrypt20 1.8.2-1 (automatically added)
Install libgd3 2.2.5-2 (automatically added)
Install libgda5.0_4 5.2.4-1 (automatically added)
Install libgdal20 2.4.0-1 (automatically added)
Install libgdata-common 0.17.9-1 (automatically added)
Install libgdata22 0.17.9-1 (automatically added)
Install libgdbm4 1.12-1
Install libgdk_pixbuf2.0-devel 2.36.11-1 (automatically added)
Install libgdk_pixbuf2.0_0 2.36.11-1 (automatically added)
Install libgdl3-common 3.26.0-1 (automatically added)
Install libgdl3_5 3.26.0-1 (automatically added)
Install libgee0.8_2 0.20.1-1 (automatically added)
Install libgeoclue0 0.12.99-2 (automatically added)
Install libgeocode-glib-common 3.24.0-1 (automatically added)
Install libgeocode-glib0 3.24.0-1 (automatically added)
Install libgeos_3_7_1 3.7.1-1 (automatically added)
Install libgeos_c1 3.7.1-1 (automatically added)
Install libgeotiff2 1.4.3-1 (automatically added)
Install libgfortran4 7.4.0-1 (automatically added)
Install libgif7 5.1.4-1 (automatically added)
Install libgirepository1.0-devel 1.54.1-1 (automatically added)
Install libgirepository1.0_1 1.54.1-1 (automatically added)
Install libgit2-glib1.0_0 0.26.2-1 (automatically added)
Install libgit2_25 0.25.1-1 (automatically added)
Install libglabels3.0-common 3.4.0-1
Install libglabels3.0-devel 3.4.0-1
Install libglabels3.0_8 3.4.0-1
Install libglade2.0_0 2.6.4-2 (automatically added)
Install libglademm2.4_1 2.6.7-11 (automatically added)
Install libglapi0 18.0.5-1 (automatically added)
Install libglbarcode3.0-devel 3.4.0-1
Install libglbarcode3.0_0 3.4.0-1
Install libglib1.2_0 1.2.10-12 (automatically added)
Install libglib2.0-devel 2.54.3-1 (automatically added)
Install libglib2.0_0 2.54.3-1 (automatically added)
Install libglibmm2.4_1 2.54.1-1 (automatically added)
Install libglut3 3.0.0-1 (automatically added)
Install libgmp-devel 6.1.2-1 (automatically added)
Install libgmp10 6.1.2-1
Install libgmpxx4 6.1.2-1 (automatically added)
Install libgnome-desktop3_12 3.26.2-1 (automatically added)
Install libgnome-keyring0 3.12.0-2 (automatically added)
Install libgnome-menu3_0 3.13.3-3 (automatically added)
Install libgnome2_0 2.32.1-3 (automatically added)
Install libgnomecanvas2_0 2.30.3-2 (automatically added)
Install libgnomekbd-common 3.26.0-1 (automatically added)
Install libgnomekbd8 3.26.0-1 (automatically added)
Install libgnomeui2_0 2.24.5-2 (automatically added)
Install libgnomevfs2_0 2.24.4-6 (automatically added)
Install libgnutls30 3.6.6-1 (automatically added)
Install libgoa-backend1.0_1 3.22.6-2 (automatically added)
Install libgoa1.0_0 3.22.6-2 (automatically added)
Install libgoffice0.10_10 0.10.38-1 (automatically added)
Install libgoffice0.8_8 0.8.17-1 (automatically added)
Install libgomp1 7.4.0-1 (automatically added)
Install libgoocanvas2.0_9 2.0.2-1 (automatically added)
Install libgoocanvas3 1.0.0-1 (automatically added)
Install libgpg-error0 1.28-1 (automatically added)
Install libgpgme11 1.9.0-1 (automatically added)
Install libgpgmepp6 1.9.0-1 (automatically added)
Install libgrantlee5 5.1.0-1 (automatically added)
Install libgraphite2-devel 1.3.10-1 (automatically added)
Install libgraphite2_3 1.3.10-1 (automatically added)
Install libgs9 9.27-1 (automatically added)
Install libgsf-common 1.14.42-1 (automatically added)
Install libgsf1_114 1.14.42-1 (automatically added)
Install libgsl19 2.3-2 (automatically added)
Install libgsm1 1.0.17-1 (automatically added)
Install libgspell1-common 1.6.1-1 (automatically added)
Install libgspell1_1 1.6.1-1 (automatically added)
Install libgssapi_krb5_2 1.15.2-2 (automatically added)
Install libgstinterfaces1.0_0 1.12.5-1 (automatically added)
Install libgstreamer1.0_0 1.12.5-1 (automatically added)
Install libgstrtspserver1.0_0 1.12.5-1 (automatically added)
Install libgtk2.0-devel 2.24.32-1 (automatically added)
Install libgtk2.0_0 2.24.32-1 (automatically added)
Install libgtk3_0 3.22.28-1 (automatically added)
Install libgtkmathview-common 0.8.0-12 (automatically added)
Install libgtkmm2.4_1 2.24.5-1 (automatically added)
Install libgtkmm3.0_1 3.22.2-1 (automatically added)
Install libgtksourceview2.0-devel 2.10.5-2 (automatically added)
Install libgtksourceview2.0_0 2.10.5-2 (automatically added)
Install libgtksourceview3.0-common 3.24.6-1 (automatically added)
Install libgtksourceview3.0_1 3.24.6-1 (automatically added)
Install libgtkspell0 2.0.16-1 (automatically added)
Install libgtkspell3-common 3.0.9-1 (automatically added)
Install libgtkspell3_3_0 3.0.9-1 (automatically added)
Install libgtop2.0_10 2.34.2-1 (automatically added)
Install libgts0.7_5 20121130-1 (automatically added)
Install libgucharmap2.90_7 10.0.3-1 (automatically added)
Install libguile17 1.8.8-3 (automatically added)
Install libguile2.0_22 2.0.14-3 (automatically added)
Install libguile2.2_1 2.2.4-1 (automatically added)
Install libgvc6 2.40.1-4 (automatically added)
Install libgweather-common 3.26.1-1 (automatically added)
Install libgweather3_6 3.26.1-1 (automatically added)
Install libgwengui-cpp0 4.20.0-1 (automatically added)
Install libgwengui-gtk2_0 4.20.0-1 (automatically added)
Install libgwengui-qt5_0 4.20.0-1 (automatically added)
Install libgwenhywfar-common 4.20.0-1 (automatically added)
Install libgwenhywfar60 4.20.0-1 (automatically added)
Install libharfbuzz-devel 1.7.6-1 (automatically added)
Install libharfbuzz-gobject0 1.7.6-1 (automatically added)
Install libharfbuzz-icu0 1.7.6-1 (automatically added)
Install libharfbuzz0 1.7.6-1 (automatically added)
Install libhdf5_101 1.10.2-1 (automatically added)
Install libhdf5hl_100 1.10.2-1 (automatically added)
Install libhogweed4 3.4.1-1 (automatically added)
Install libhunspell1.6_0 1.6.1-1 (automatically added)
Install libhyphen0 2.8.8-1 (automatically added)
Install libical2 2.0.0-2 (automatically added)
Install libiconv 1.14-3
Install libiconv-devel 1.14-3 (automatically added)
Install libiconv2 1.14-3
Install libicu56 56.1-1 (automatically added)
Install libicu61 61.1-1 (automatically added)
Install libicu63 63.1-1 (automatically added)
Install libicu64 64.2-1 (automatically added)
Install libid3_3.8.3 3.8.3-3 (automatically added)
Install libid3tag0 0.15.1b-10 (automatically added)
Install libidn11 1.33-1 (automatically added)
Install libidn2_0 2.0.4-1 (automatically added)
Install libiec16022_0 0.2.4-1 (automatically added)
Install libilmbase12 2.2.0-1 (automatically added)
Install libimagequant0 2.10.0-1 (automatically added)
Install libinchi0 2.3.2-6 (automatically added)
Install libintl-devel 0.19.8.1-2 (automatically added)
Install libintl8 0.19.8.1-2
Install libiodbc2 3.52.8-2 (automatically added)
Install libirs161 9.11.6-1 (automatically added)
Install libisc1100 9.11.6-1 (automatically added)
Install libisccc161 9.11.6-1 (automatically added)
Install libisccfg163 9.11.6-1 (automatically added)
Install libisl15 0.16.1-1 (automatically added)
Install libiso9660_11 2.0.0-1 (automatically added)
Install libjasper4 2.0.14-1 (automatically added)
Install libjavascriptcoregtk1.0_0 2.0.4-5 (automatically added)
Install libjavascriptcoregtk3.0_0 2.0.4-5 (automatically added)
Install libjbig2 2.0-14 (automatically added)
Install libjpeg8 1.5.3-1 (automatically added)
Install libjq1 1.6-1 (automatically added)
Install libjson-c-common 0.12-1 (automatically added)
Install libjson-c2 0.12-1 (automatically added)
Install libjson-glib1.0_0 1.4.2-1 (automatically added)
Install libk5crypto3 1.15.2-2 (automatically added)
Install libkpathsea-devel 20190509-1
Install libkpathsea6 20190509-1
Install libkrb5_3 1.15.2-2 (automatically added)
Install libkrb5support0 1.15.2-2 (automatically added)
Install libktoblzcheck-common 1.49-1 (automatically added)
Install libktoblzcheck1 1.49-1 (automatically added)
Install liblangtag-common 0.6.0-1 (automatically added)
Install liblangtag1 0.6.0-1 (automatically added)
Install liblapack0 3.8.0-1 (automatically added)
Install liblasem0.4_4 0.4.3-1 (automatically added)
Install liblcms1 1.19-5 (automatically added)
Install liblcms2_2 2.9-1 (automatically added)
Install liblink-grammar-common 5.3.16-2 (automatically added)
Install liblink-grammar4 4.8.6-2
Install liblink-grammar5 5.3.16-2 (automatically added)
Install libllvm5.0 5.0.1-1 (automatically added)
Install liblmdb0 0.9.19-1 (automatically added)
Install libloudmouth1_0 1.5.3-1 (automatically added)
Install libltdl7 2.4.6-6 (automatically added)
Install liblwres161 9.11.6-1 (automatically added)
Install liblz4_1 1.7.5-1 (automatically added)
Install liblzma5 5.2.3-1
Install liblzo2_2 2.10-1 (automatically added)
Install libmad0 0.15.1b-11 (automatically added)
Install libmailutils-sieve-extensions 3.5-1 (automatically added)
Install libmailutils5 3.5-1
Install libmariadb-devel 3.0.9-1 (automatically added)
Install libmariadb3 3.0.9-1 (automatically added)
Install libmarisa0 0.2.4-4 (automatically added)
Install libmathview0 0.8.0-12 (automatically added)
Install libmdb1 0.6pre1-4 (automatically added)
Install libmediainfo0 17.12-1 (automatically added)
Install libmetalink3 0.1.2-1 (automatically added)
Install libming1 0.4.8-3 (automatically added)
Install libmng2 2.0.3-1 (automatically added)
Install libmp3lame0 3.100-1 (automatically added)
Install libmp4v2_2 2.0.0-1 (automatically added)
Install libmpc3 1.1.0-1 (automatically added)
Install libmpd1 11.8.17-2 (automatically added)
Install libmpfr4 3.1.6-1p1 (automatically added)
Install libmpfr6 4.0.2-1
Install libmsi0 0.97-1 (automatically added)
Install libmspack0 0.5-0.1.alpha (automatically added)
Install libmspub-tools 0.1.3-2 (automatically added)
Install libmspub0.1_1 0.1.3-2 (automatically added)
Install libmwaw-tools 0.3.13-1 (automatically added)
Install libmwaw0.3_3 0.3.13-1 (automatically added)
Install libmysqlclient18 10.1.30-1 (automatically added)
Install libncursesw10 6.0-12.20171125
Install libneko2 2.2.0-1 (automatically added)
Install libneon27 0.30.1-1 (automatically added)
Install libnetcdf13 4.6.1-2 (automatically added)
Install libnettle6 3.4.1-1 (automatically added)
Install libnfs-utils 1.11.0-1
Install libnfs8 1.11.0-1 (automatically added)
Install libnghttp2_14 1.37.0-1 (automatically added)
Install libnotify-debuginfo 0.7.7-1
Install libnotify4 0.7.7-1 (automatically added)
Install libnspr4 4.20-1 (automatically added)
Install libnss3 3.42.1-1 (automatically added)
Install liboauth-common 1.0.3-1 (automatically added)
Install liboauth0 1.0.3-1 (automatically added)
Install libodfgen0.1_1 0.1.6-2 (automatically added)
Install libofx-common 0.9.12-1 (automatically added)
Install libofx-tools 0.9.12-1
Install libofx7 0.9.12-1 (automatically added)
Install libogg0 1.3.1-1 (automatically added)
Install libonig5 6.9.1-1 (automatically added)
Install libopenbabel4 2.3.2-6 (automatically added)
Install libopenblas 0.3.5-1 (automatically added)
Install libopenjp2_7 2.3.0-1 (automatically added)
Install libopenldap2_4_2 2.4.42-1 (automatically added)
Install libopts25 5.18.16-1 (automatically added)
Install libopus0 1.2.1-1 (automatically added)
Install libopusfile0 0.10-1 (automatically added)
Install liborc0.4-devel 0.4.28-1 (automatically added)
Install liborc0.4_0 0.4.28-1 (automatically added)
Install libosp5 1.5.2-2 (automatically added)
Install libostyle-devel 1.4devel1-3
Install libostyle1 1.4devel1-3 (automatically added)
Install libotf-devel 0.9.13-1
Install libotf0 0.9.13-1 (automatically added)
Install libots1_0 0.5.0-10 (automatically added)
Install libp11-kit0 0.23.15-1
Install libpagemaker-tools 0.0.3-2 (automatically added)
Install libpagemaker0.0_0 0.0.3-2 (automatically added)
Install libpango1.0-devel 1.40.14-1 (automatically added)
Install libpango1.0_0 1.40.14-1 (automatically added)
Install libpangomm1.4_1 2.40.1-1 (automatically added)
Install libpaper-common 1.1.24-2 (automatically added)
Install libpaper1 1.1.24-2 (automatically added)
Install libpathplan4 2.40.1-4 (automatically added)
Install libpcre-devel 8.43-1 (automatically added)
Install libpcre1 8.43-1
Install libpcre16_0 8.43-1 (automatically added)
Install libpcre2-posix2 10.32-1 (automatically added)
Install libpcre2_16_0 10.32-1 (automatically added)
Install libpcre2_32_0 10.32-1 (automatically added)
Install libpcre2_8_0 10.32-1 (automatically added)
Install libpcre32_0 8.43-1 (automatically added)
Install libpcrecpp0 8.43-1 (automatically added)
Install libpcreposix0 8.43-1 (automatically added)
Install libpeas-common 1.22.0-1 (automatically added)
Install libpeas1.0_0 1.22.0-1 (automatically added)
Install libphonon4qt5_4 4.9.1-2 (automatically added)
Install libpipeline1 1.4.0-1
Install libpixman1-devel 0.34.0-1 (automatically added)
Install libpixman1_0 0.34.0-1 (automatically added)
Install libpkgconf3 1.6.0-1 (automatically added)
Install libplotter2 2.6-5 (automatically added)
Install libpng-devel 1.6.34-1 (automatically added)
Install libpng16 1.6.34-1 (automatically added)
Install libpng16-devel 1.6.34-1 (automatically added)
Install libpodofo0.9.5 0.9.5-1 (automatically added)
Install libpoppler-glib8 0.62.0-1 (automatically added)
Install libpoppler66 0.52.0-2 (automatically added)
Install libpoppler73 0.62.0-1 (automatically added)
Install libpopt-common 1.16-2
Install libpopt0 1.16-2
Install libportaudio2 19.20140130-3 (automatically added)
Install libpq5 11.2-1 (automatically added)
Install libproj13 5.2.0-1 (automatically added)
Install libproxy1 0.4.14-2 (automatically added)
Install libpsiconv6 0.9.9-1 (automatically added)
Install libpsl5 0.18.0-1 (automatically added)
Install libpstoedit0 3.73-1 (automatically added)
Install libptexenc-devel 20190509-1
Install libptexenc1 20190509-1
Install libpugixml1 1.9-1 (automatically added)
Install libpulse-mainloop-glib0 11.1-1 (automatically added)
Install libpulse-simple0 11.1-1 (automatically added)
Install libpulse0 11.1-1 (automatically added)
Install libpurple0 2.13.0-1 (automatically added)
Install libqca-qt5_2 2.1.3-1 (automatically added)
Install libqhull_7 2018.1-1 (automatically added)
Install libqrencode3 3.4.4-1 (automatically added)
Install libquadmath0 7.4.0-1 (automatically added)
Install libqxp-tools 0.0.1-2 (automatically added)
Install libqxp0.0_0 0.0.1-2 (automatically added)
Install libraptor2_0 2.0.15-1 (automatically added)
Install librasqal3 0.9.33-1 (automatically added)
Install librdf0 1.0.17-2 (automatically added)
Install libreadline7 7.0.3-3
Install librest0.7_0 0.8.1-1 (automatically added)
Install librevenge0.0_0 0.0.4-2 (automatically added)
Install librsvg2_2 2.40.20-1 (automatically added)
Install librvngabw0.0_0 0.0.2-1 (automatically added)
Install libsamplerate0 0.1.8-1 (automatically added)
Install libsasl2_3 2.1.26-11 (automatically added)
Install libsecret1_0 0.18.5-1 (automatically added)
Install libserf1_0 1.3.9-1 (automatically added)
Install libshout3 2.4.1-1 (automatically added)
Install libsigc2.0_0 2.10.0-1 (automatically added)
Install libsigsegv2 2.10-2
Install libslang2 2.3.2-2 (automatically added)
Install libsmartcols1 2.33.1-1
Install libsnappy1 1.1.7-1 (automatically added)
Install libsndfile1 1.0.28-2 (automatically added)
Install libsodium-common 1.0.16-1 (automatically added)
Install libsodium23 1.0.16-1 (automatically added)
Install libsolv0 0.6.34-1 (automatically added)
Install libsoup-gnome2.4_1 2.60.3-1 (automatically added)
Install libsoup2.4_1 2.60.3-1 (automatically added)
Install libsource-highlight-common 3.1.8-6 (automatically added)
Install libsource-highlight4 3.1.8-6 (automatically added)
Install libsox3 14.4.2-5
Install libsoxr0 0.1.2-1 (automatically added)
Install libspectre1 0.2.8-1 (automatically added)
Install libspeechd-devel 0.8.7-1
Install libspeechd2 0.8.7-1
Install libspeex1 1.2.0-2 (automatically added)
Install libspeexdsp1 1.2-0.1.rc3 (automatically added)
Install libsqlite3_0 3.28.0-1 (automatically added)
Install libssh-common 0.8.7-1 (automatically added)
Install libssh2-debuginfo 1.7.0-1
Install libssh2_1 1.7.0-1 (automatically added)
Install libssh4 0.8.7-1 (automatically added)
Install libssl-devel 1.1.1b-1 (automatically added)
Install libssl1.0 1.0.2r-2 (automatically added)
Install libssl1.1 1.1.1b-1
Install libssp0 6.4.0-4 (automatically added)
Install libstaroffice-tools 0.0.5-1 (automatically added)
Install libstaroffice0.0_0 0.0.5-1 (automatically added)
Install libstartup-notification1_0 0.12-2 (automatically added)
Install libstdc++6 7.4.0-1
Install libsybdb5 1.00.37-1 (automatically added)
Install libsynctex-devel 20190509-1
Install libsynctex1 20180918-1
Install libsynctex2 20190509-1
Install libtag1 1.11.1-1 (automatically added)
Install libtag_c0 1.11.1-1 (automatically added)
Install libtasn1_6 4.13-1
Install libtdb1 1.2.11-2 (automatically added)
Install libteckit0 2.5.9-1
Install libtelepathy-glib0 0.24.1-1 (automatically added)
Install libtepl3_0 3.0.0-1 (automatically added)
Install libtexlua52-devel 20180918-1
Install libtexlua52_5 20180918-1
Install libtexlua53-devel 20190509-1
Install libtexlua53_5 20190509-1
Install libtexluajit-devel 20190509-1
Install libtexluajit2 20190509-1
Install libthai0 0.1.26-1 (automatically added)
Install libtheora 1.1.1-2 (automatically added)
Install libtheora0 1.1.1-2 (automatically added)
Install libtheoradec1 1.1.1-2 (automatically added)
Install libtheoraenc1 1.1.1-2 (automatically added)
Install libtidy0_99_0 20090325-1
Install libtiff6 4.0.9-1 (automatically added)
Install libtinyxml2_6 6.0.0-1 (automatically added)
Install libtirpc-common 1.1.4-1 (automatically added)
Install libtirpc3 1.1.4-1 (automatically added)
Install libtool 2.4.6-6 (automatically added)
Install libtracker2.0_0 2.0.3-2 (automatically added)
Install libtwolame0 0.3.13-2 (automatically added)
Install libuchardet0 0.0.6-1 (automatically added)
Install libunbound-common 1.6.2-1 (automatically added)
Install libunbound2 1.6.2-1 (automatically added)
Install libunique1.0_0 1.1.6-1 (automatically added)
Install libunistring2 0.9.10-1 (automatically added)
Install libusb0 1.2.6.0-2 (automatically added)
Install libuuid-devel 2.33.1-1 (automatically added)
Install libuuid1 2.33.1-1
Install libvala0.38_0 0.38.8-1 (automatically added)
Install libvcdinfo0 2.0.1-1
Install libvisio-tools 0.1.6-2 (automatically added)
Install libvisio0.1_1 0.1.6-2 (automatically added)
Install libvoikko1 3.8-1 (automatically added)
Install libvorbis 1.3.6-1 (automatically added)
Install libvorbis0 1.3.6-1 (automatically added)
Install libvorbisenc2 1.3.6-1 (automatically added)
Install libvorbisfile3 1.3.6-1 (automatically added)
Install libvpx5 1.7.0-1 (automatically added)
Install libvte2.91_0 0.50.2-1 (automatically added)
Install libvte9 0.28.2-6 (automatically added)
Install libwavpack1 5.1.0-2 (automatically added)
Install libwebkitgtk1.0_0 2.0.4-5 (automatically added)
Install libwebkitgtk3.0_0 2.0.4-5 (automatically added)
Install libwebp5 0.4.4-1 (automatically added)
Install libwebp7 0.6.1-2 (automatically added)
Install libwebpdemux2 0.6.1-2 (automatically added)
Install libwebpmux3 0.6.1-2 (automatically added)
Install libwebrtc-audio-processing1 0.3-1 (automatically added)
Install libwinpr2_2 2.0.0-0.6.rc2 (automatically added)
Install libwmf027 0.2.8.4-15 (automatically added)
Install libwnck1_22 2.30.7-2 (automatically added)
Install libwnck3_0 3.24.1-1 (automatically added)
Install libwpd-tools 0.10.2-1 (automatically added)
Install libwpd0.10_10 0.10.2-1 (automatically added)
Install libwpg-tools 0.3.2-1 (automatically added)
Install libwpg0.3_3 0.3.2-1 (automatically added)
Install libwps-tools 0.4.8-1
Install libwps0.4_4 0.4.8-1 (automatically added)
Install libwrap0 7.6-26 (automatically added)
Install libwsman-common 2.6.5-1 (automatically added)
Install libwsman1 2.6.5-1 (automatically added)
Install libwsman_client4 2.6.5-1 (automatically added)
Install libwv1.2_4 1.2.9-2 (automatically added)
Install libwx_baseu2.8_0 2.8.12.1-7 (automatically added)
Install libwx_baseu3.0_0 3.0.3-1 (automatically added)
Install libwx_gtk2u2.8_0 2.8.12.1-7 (automatically added)
Install libwx_gtk2u3.0_0 3.0.3-1 (automatically added)
Install libwx_gtk3u3.0_0 3.0.3-1 (automatically added)
Install libxapian30 1.4.5-1 (automatically added)
Install libxapp-common 1.0.4-1 (automatically added)
Install libxapp1 1.0.4-1 (automatically added)
Install libxcb-devel 1.12-2 (automatically added)
Install libxcb-dri2_0 1.12-2 (automatically added)
Install libxcb-glx0 1.12-2 (automatically added)
Install libxcb-icccm4 0.4.1-1 (automatically added)
Install libxcb-image0 0.3.9-1 (automatically added)
Install libxcb-keysyms1 0.3.9-1 (automatically added)
Install libxcb-randr0 1.12-2 (automatically added)
Install libxcb-render-devel 1.12-2 (automatically added)
Install libxcb-render-util0 0.3.9-1 (automatically added)
Install libxcb-render0 1.12-2 (automatically added)
Install libxcb-shape0 1.12-2 (automatically added)
Install libxcb-shm-devel 1.12-2 (automatically added)
Install libxcb-shm0 1.12-2 (automatically added)
Install libxcb-sync1 1.12-2 (automatically added)
Install libxcb-util1 0.3.9-1 (automatically added)
Install libxcb-xfixes0 1.12-2 (automatically added)
Install libxcb-xinerama0 1.12-2 (automatically added)
Install libxcb-xkb1 1.12-2 (automatically added)
Install libxcb1 1.12-2 (automatically added)
Install libxdelta2 1.1.4-2 (automatically added)
Install libxfce4ui-common 4.12.1-1 (automatically added)
Install libxfce4ui2_0 4.12.1-1 (automatically added)
Install libxfce4util-common 4.12.1-1 (automatically added)
Install libxfce4util7 4.12.1-1 (automatically added)
Install libxfconf0_2 4.12.0-2 (automatically added)
Install libxkbcommon0 0.8.0-1 (automatically added)
Install libxkbfile1 1.0.9-1 (automatically added)
Install libxklavier16 5.3-1 (automatically added)
Install libxml++2.6_2 2.40.1-1 (automatically added)
Install libxml2 2.9.9-2 (automatically added)
Install libxml2-devel 2.9.9-2 (automatically added)
Install libxmlsec1-gcrypt1 1.2.24-1 (automatically added)
Install libxmlsec1-gnutls1 1.2.24-1 (automatically added)
Install libxmlsec1_1 1.2.24-1 (automatically added)
Install libxmp4 4.4.0-1 (automatically added)
Install libxslt 1.1.29-1 (automatically added)
Install libyajl2 2.1.0-1 (automatically added)
Install libyaml0_2 0.1.6-2 (automatically added)
Install libyaz5 5.23.1-2 (automatically added)
Install libzbar0 0.10-9 (automatically added)
Install libzen0 0.4.37-1 (automatically added)
Install libzinnia0 0.06-10 (automatically added)
Install libzint2.4 2.4.3-3 (automatically added)
Install libzip-tools 1.5.1-1
Install libzip5 1.5.1-1 (automatically added)
Install libzmf-tools 0.0.2-2 (automatically added)
Install libzmf0.0_0 0.0.2-2 (automatically added)
Install libzzip0.13 0.13.68-1 (automatically added)
Install licensecheck 2.15.8-1
Install lighttpd 1.4.53-1 (automatically added)
Install lilypond 2.19.82-1
Install link-grammar-en 5.3.16-2 (automatically added)
Install linklint 2.3.5-1
Install links 2.14-1
Install lndir 1.0.3-1 (automatically added)
Install login 1.13-1
Install lua 5.3.5-1 (automatically added)
Install lyx 2.3.2-1
Install lzop 1.03-1 (automatically added)
Install m4 1.4.18-1 (automatically added)
Install make 4.2.1-2
Install makedepend 1.0.5-1
Install makepasswd 1.10-2
Install man-db 2.7.6.1-1
Install mariadb-common 3.0.9-1 (automatically added)
Install mariadb-connector-odbc 3.0.8-1
Install mate-common 1.20.0-1
Install mboxcheck 0.1.2-2
Install mediainfo-qt 17.12-1
Install mingw64-i686-atk1.0 2.26.1-1 (automatically added)
Install mingw64-i686-binutils 2.29.1.787c9873-1 (automatically added)
Install mingw64-i686-bzip2 1.0.6-4 (automatically added)
Install mingw64-i686-cairo 1.14.12-1 (automatically added)
Install mingw64-i686-chromaprint 1.4.3-1
Install mingw64-i686-clutter-gst3.0 3.0.24-1
Install mingw64-i686-clutter-gtk1.0 1.8.4-1
Install mingw64-i686-clutter1.0 1.26.2-1
Install mingw64-i686-cogl 1.22.2-1 (automatically added)
Install mingw64-i686-crypt 2.1-1
Install mingw64-i686-curl 7.59.0-1
Install mingw64-i686-expat 2.2.2-1 (automatically added)
Install mingw64-i686-fftw3 3.3.5-1 (automatically added)
Install mingw64-i686-fontconfig 2.12.6-1 (automatically added)
Install mingw64-i686-freeglut 2.8.1-1 (automatically added)
Install mingw64-i686-freetype2 2.8.1-1 (automatically added)
Install mingw64-i686-gcc-core 7.4.0-1 (automatically added)
Install mingw64-i686-gcc-g++ 7.4.0-1 (automatically added)
Install mingw64-i686-gdk-pixbuf2.0 2.36.11-1 (automatically added)
Install mingw64-i686-gettext 0.19.8.1-2 (automatically added)
Install mingw64-i686-glib2.0 2.54.3-1 (automatically added)
Install mingw64-i686-gstreamer1.0 1.12.5-1
Install mingw64-i686-gstreamer1.0-editing-services 1.12.5-1
Install mingw64-i686-gstreamer1.0-plugins-base 1.12.5-1 (automatically added)
Install mingw64-i686-gtk3 3.22.28-1 (automatically added)
Install mingw64-i686-harfbuzz 1.7.6-1 (automatically added)
Install mingw64-i686-headers 6.0.0-1 (automatically added)
Install mingw64-i686-jasper 2.0.14-1 (automatically added)
Install mingw64-i686-jbigkit 2.1-1 (automatically added)
Install mingw64-i686-json-glib1.0 1.4.2-1 (automatically added)
Install mingw64-i686-lame 3.100-1
Install mingw64-i686-lcms2 2.9-1
Install mingw64-i686-libcaca 0.99.beta19-1
Install mingw64-i686-libcdio 2.0.0-1 (automatically added)
Install mingw64-i686-libcdio-paranoia 10.2+0.94+2-1 (automatically added)
Install mingw64-i686-libepoxy 1.4.3-1 (automatically added)
Install mingw64-i686-libffi 3.2.1-1 (automatically added)
Install mingw64-i686-libjpeg-turbo 1.5.3-1 (automatically added)
Install mingw64-i686-libogg 1.3.2-1 (automatically added)
Install mingw64-i686-libpng 1.6.34-1 (automatically added)
Install mingw64-i686-libssh2 1.7.0-2
Install mingw64-i686-libtheora 1.1.1-2 (automatically added)
Install mingw64-i686-libvorbis 1.3.6-1 (automatically added)
Install mingw64-i686-libxml2 2.9.4-1 (automatically added)
Install mingw64-i686-lzo2 2.08-1 (automatically added)
Install mingw64-i686-nghttp2 1.31.0-1 (automatically added)
Install mingw64-i686-openssl 1.0.2o-1 (automatically added)
Install mingw64-i686-opus 1.2.1-1 (automatically added)
Install mingw64-i686-orc0.4 0.4.28-1 (automatically added)
Install mingw64-i686-pango1.0 1.40.14-1 (automatically added)
Install mingw64-i686-pcre 8.40-3 (automatically added)
Install mingw64-i686-pixman 0.34.0-1 (automatically added)
Install mingw64-i686-runtime 6.0.0-1 (automatically added)
Install mingw64-i686-tiff 4.0.9-1 (automatically added)
Install mingw64-i686-win-iconv 0.0.6-2 (automatically added)
Install mingw64-i686-windows-default-manifest 6.4-1 (automatically added)
Install mingw64-i686-winpthreads 6.0.0-1 (automatically added)
Install mingw64-i686-xz 5.2.3-1 (automatically added)
Install mingw64-i686-zlib 1.2.11-1 (automatically added)
Install mingw64-x86_64-headers 6.0.0-1 (automatically added)
Install mingw64-x86_64-libssh2 1.7.0-2
Install mingw64-x86_64-runtime 6.0.0-1 (automatically added)
Install mingw64-x86_64-winpthreads 6.0.0-1 (automatically added)
Install mingw64-x86_64-zlib 1.2.11-1 (automatically added)
Install mintty 3.0.0-1
Install most 5.0.0.1-1
Install mp4v2 2.0.0-1
Install multitail 6.4.2-1
Install mutagen-utils 1.42.0-1
Install mysql 10.3.14-1
Install mysql-bench 10.3.14-1
Install mysql-common 10.3.14-1
Install mysql-debuginfo 10.3.14-1
Install mysql-devel 10.3.14-1
Install mysql-errmsg 10.3.14-1
Install mysql-server 10.3.14-1
Install mysql-server-utils 10.3.14-1
Install nano 2.9.7-1
Install ncurses 6.0-12.20171125
Install net-snmp-agent-libs 5.7.3-1 (automatically added)
Install net-snmp-libs 5.7.3-1 (automatically added)
Install nginx 1.14.2-1
Install nginx-mod_http_perl 1.14.2-1
Install nginx-mod_mail 1.14.2-1
Install nginx-mod_stream 1.14.2-1
Install odbc-mysql 5.2.5-1
Install odbc-mysql-debuginfo 5.2.5-1
Install offlineimap 6.5.5-1
Install openjade 1.4devel1-3 (automatically added)
Install openssh 8.0p1-2
Install openssl 1.1.1b-1
Install openssl-perl 1.1.1b-1
Install opus-tools 0.1.10-1
Install ots 0.5.0-10
Install p11-kit 0.23.15-1
Install p11-kit-trust 0.23.15-1
Install p7zip 15.14.1-1 (automatically added)
Install paman 0.9.4-2
Install pamixer 1.3.1-4
Install paprefs 0.9.10-2
Install par 1.52-5
Install parole 0.8.1-1
Install pasystray 0.6.0-4
Install patch 2.7.4-1 (automatically added)
Install patcher 0.0.20040521-1
Install patchutils 0.3.4-1
Install pavucontrol 3.0-1
Install pavumeter 0.9.3-2
Install pcre2 10.32-1
Install perl 5.26.3-1
Install perl-Algorithm-Combinatorics 0.27-1
Install perl-Algorithm-Diff 1.1903-3
Install perl-Alien-wxWidgets 0.69-1
Install perl-Archive-Extract 0.80-2
Install perl-Archive-Zip 1.64-1
Install perl-Astro-FITS-CFITSIO 1.12-1
Install perl-Authen-SASL 2.16-3
Install perl-Authen-SASL-XS 1.00-2
Install perl-B-Generate 1.56-1
Install perl-B-Hooks-EndOfScope 0.24-1
Install perl-Barcode-ZBar 0.10-9
Install perl-Business-ISBN 3.004-2
Install perl-Business-ISBN-Data 20140910.003-2
Install perl-Business-ISMN 1.201-1
Install perl-Business-ISSN 1.003-1
Install perl-CGI 4.43-1
Install perl-CPAN-Changes 0.400002-2
Install perl-CPAN-DistnameInfo 0.12-6
Install perl-CPAN-Meta-Check 0.014-2
Install perl-CPAN-Meta-YAML 0.018-2
Install perl-CPAN-Reporter 1.2018-2
Install perl-CPAN-Testers-Report 1.999003-3
Install perl-Cairo 1.106-2
Install perl-Cairo-GObject 1.004-3
Install perl-Canary-Stability 2013-1
Install perl-Capture-Tiny 0.48-1
Install perl-Carp 1.38-2 (automatically added)
Install perl-Chemistry-OpenBabel 2.3.2-6
Install perl-Class-Accessor 0.51-1
Install perl-Class-Data-Inheritable 0.08-2
Install perl-Class-Factory-Util 1.7-2
Install perl-Class-Inspector 1.34-1
Install perl-Class-Singleton 1.5-2
Install perl-Class-Tiny 1.006-2
Install perl-Class-XSAccessor 1.19-4
Install perl-Clone 0.41-1
Install perl-Compress-Bzip2 2.26-2
Install perl-Config-AutoConf 0.317-1
Install perl-Config-Tiny 2.23-2
Install perl-Cpanel-JSON-XS 4.11-1
Install perl-Crypt-OpenSSL-Bignum 0.09-1
Install perl-Crypt-OpenSSL-DSA 0.19-2
Install perl-Crypt-OpenSSL-EC 1.31-2
Install perl-Crypt-OpenSSL-ECDSA 0.08-3
Install perl-Crypt-OpenSSL-Guess 0.11-1
Install perl-Crypt-OpenSSL-RSA 0.31-1
Install perl-Crypt-OpenSSL-Random 0.15-1
Install perl-DBD-SQLite 1.62-1
Install perl-DBD-mysql 4.050-1
Install perl-DBD-mysql-debuginfo 4.050-1
Install perl-DBI 1.642-1
Install perl-Data-Compare 1.25-3
Install perl-Data-Diver 1.0101-4
Install perl-Data-Dump 1.23-2
Install perl-Data-GUID 0.049-2
Install perl-Data-OptList 0.110-2
Install perl-Data-UUID 1.224-1
Install perl-Data-Uniqid 0.12-2
Install perl-Date-Manip 6.76-1
Install perl-Date-Simple 3.03-3
Install perl-DateTime 1.51-1
Install perl-DateTime-Calendar-Julian 0.100-1
Install perl-DateTime-Format-Builder 0.82-1
Install perl-DateTime-Format-Strptime 1.76-1
Install perl-DateTime-Locale 1.24-1
Install perl-DateTime-TimeZone 2.35-1
Install perl-Devel-Autoflush 0.06-3
Install perl-Devel-CheckLib 1.13-1
Install perl-Devel-GlobalDestruction 0.14-2
Install perl-Devel-StackTrace 2.03-1
Install perl-Devel-Symdump 2.18-2
Install perl-Digest-BubbleBabble 0.02-4
Install perl-Digest-GOST 0.06-2
Install perl-Digest-HMAC 1.03-6
Install perl-Digest-SHA 6.02-1
Install perl-Digest-SHA1 2.13-6
Install perl-Dist-CheckConflicts 0.11-3
Install perl-Encode-EUCJPASCII 0.03-3
Install perl-Encode-HanExtra 0.23-3
Install perl-Encode-ISO2022 0.04-4
Install perl-Encode-JIS2K 0.03-2
Install perl-Encode-JISX0213 0.04-2
Install perl-Encode-Locale 1.05-2
Install perl-Error 0.17027-1
Install perl-Eval-Closure 0.14-2
Install perl-Exception-Class 1.44-1
Install perl-Exporter-Tiny 1.002001-1
Install perl-ExtUtils-CBuilder 0.280231-1
Install perl-ExtUtils-Config 0.008-3
Install perl-ExtUtils-Depends 0.8000-1
Install perl-ExtUtils-F77 1.23-1
Install perl-ExtUtils-Helpers 0.026-2
Install perl-ExtUtils-InstallPaths 0.012-1
Install perl-ExtUtils-LibBuilder 0.08-2
Install perl-ExtUtils-MakeMaker 7.36-1
Install perl-ExtUtils-PkgConfig 1.16-2
Install perl-ExtUtils-XSpp 0.18-3
Install perl-File-Copy-Recursive 0.44-1
Install perl-File-Find-Object 0.3.2-2
Install perl-File-Find-Object-Rule 0.0310-1
Install perl-File-Find-Rule 0.34-2
Install perl-File-HomeDir 1.004-1
Install perl-File-Listing 6.04-6
Install perl-File-Remove 1.58-1
Install perl-File-ShareDir 1.116-1
Install perl-File-ShareDir-Install 0.13-1
Install perl-File-Slurp 9999.27-1
Install perl-File-Slurp-Tiny 0.004-2
Install perl-File-Slurper 0.012-1
Install perl-File-Which 1.23-1
Install perl-File-pushd 1.016-1
Install perl-Finance-Quote 1.47-1
Install perl-Font-AFM 1.20-2
Install perl-Font-TTF 1.06-2
Install perl-GD 2.66-1
Install perl-GStreamer1 0.003-2
Install perl-Getopt-ArgvFile 1.11-3
Install perl-Glib 1.326-1
Install perl-Glib-Object-Introspection 0.043-1
Install perl-Gnome2 1.046-2
Install perl-Gnome2-Canvas 1.002-13
Install perl-Gnome2-GConf 1.044-13
Install perl-Gnome2-Rsvg 0.11-3
Install perl-Gnome2-VFS 1.083-1
Install perl-Gnome2-Vte 0.11-3
Install perl-Gnome2-Wnck 0.16-13
Install perl-Gtk2 1.24992-1
Install perl-Gtk2-GladeXML 1.007-13
Install perl-Gtk2-Notify 0.05-13
Install perl-Gtk2-Notify-debuginfo 0.05-13
Install perl-Gtk2-SourceView2 0.10-4
Install perl-Gtk2-Spell 1.04-3
Install perl-Gtk2-Unique 0.05-4
Install perl-Gtk2-WebKit 0.09-3
Install perl-Gtk3 0.032-1
Install perl-HTML-Element-Extended 1.18-2
Install perl-HTML-Formatter 2.16-3
Install perl-HTML-Parser 3.72-2
Install perl-HTML-TableExtract 2.15-2
Install perl-HTML-Tagset 3.20-6
Install perl-HTML-Tree 5.07-1
Install perl-HTTP-Cookies 6.04-2
Install perl-HTTP-Daemon 6.04-1
Install perl-HTTP-Date 6.02-6
Install perl-HTTP-Message 6.18-1
Install perl-HTTP-Negotiate 6.01-6
Install perl-HTTP-Tiny 0.076-1
Install perl-IO-CaptureOutput 1.1104-3
Install perl-IO-HTML 1.001-3
Install perl-IO-Prompt-Tiny 0.003-3
Install perl-IO-Socket-INET6 2.72-3
Install perl-IO-Socket-IP 0.39-2
Install perl-IO-Socket-SSL 2.066-1
Install perl-IO-String 1.08-6
Install perl-IO-Tty 1.12-3
Install perl-IO-stringy 2.111-2
Install perl-IPC-Cmd 1.02-1
Install perl-IPC-Run 20180523.0-1
Install perl-IPC-Run3 0.048-3
Install perl-IPC-System-Simple 1.25-1
Install perl-Image-Magick 6.9.10.11-1 (automatically added)
Install perl-Importer 0.025-1
Install perl-Inline 0.83-1
Install perl-Inline-Files 0.71-1
Install perl-JSON 4.02-1
Install perl-JSON-MaybeXS 1.004000-1
Install perl-JSON-PP 4.02-1
Install perl-JSON-XS 3.04-2
Install perl-LWP-MediaTypes 6.04-1
Install perl-LWP-Online 1.08-2
Install perl-LWP-Protocol-https 6.07-2
Install perl-Lchown 1.01-2
Install perl-Lingua-Translit 0.28-1
Install perl-List-AllUtils 0.15-1
Install perl-List-MoreUtils 0.428-1
Install perl-List-MoreUtils-XS 0.428-1
Install perl-List-SomeUtils 0.56-2
Install perl-List-SomeUtils-XS 0.58-1
Install perl-List-UtilsBy 0.11-1
Install perl-Log-Log4perl 1.49-2
Install perl-MIME-Base32 1.303-2
Install perl-MIME-Charset 1.012.2-2
Install perl-MIME-Types 2.17-1
Install perl-MIME-tools 5.508-2
Install perl-MRO-Compat 0.13-2
Install perl-Mail-Box 3.007-1
Install perl-Mail-Box-Parser-C 3.009-1
Install perl-Mail-IMAPClient 3.42-1
Install perl-Mail-Message 3.008-1
Install perl-Mail-Transport 3.004-1
Install perl-MailTools 2.20-1
Install perl-Math-Int64 0.54-2
Install perl-Metabase-Client-Simple 0.012-2
Install perl-Metabase-Fact 0.025-2
Install perl-Mock-Config 0.03-2
Install perl-Module-Build 0.4229-1
Install perl-Module-Build-Tiny 0.039-3
Install perl-Module-Implementation 0.09-2
Install perl-Module-Install 1.19-1
Install perl-Module-Metadata 1.000036-1
Install perl-Module-Pluggable 5.2-2
Install perl-Module-Runtime 0.016-1
Install perl-Module-ScanDeps 1.27-1
Install perl-Module-Signature 0.83-1
Install perl-Mojolicious 8.15-1
Install perl-Mozilla-CA 20180117-1
Install perl-Net-DNS 1.20-1
Install perl-Net-DNS-SEC 1.12-1
Install perl-Net-HTTP 6.18-1
Install perl-Net-IP 1.26-4
Install perl-Net-Libproxy 0.4.14-2
Install perl-Net-SMTP-SSL 1.04-2
Install perl-Net-SSLeay 1.85-1
Install perl-Net-XMPP 1.05-2
Install perl-Number-Compare 0.03-6
Install perl-Object-Realize-Later 0.21-1
Install perl-OpenGL 0.7000-1
Install perl-PAR 1.015-2
Install perl-PAR-Dist 0.49-4
Install perl-PAR-Packer 1.040-1
Install perl-POD2-Base 0.043-3
Install perl-Package-DeprecationManager 0.17-2
Install perl-Package-Stash 0.38-1
Install perl-Package-Stash-XS 0.29-1
Install perl-PadWalker 2.3-1
Install perl-Pango 1.227-2
Install perl-Params-Util 1.07-6
Install perl-Params-Validate 1.29-2
Install perl-Params-ValidationCompiler 0.30-1
Install perl-Parse-RecDescent 1.967015-2
Install perl-Path-Class 0.37-2
Install perl-Path-Tiny 0.108-1
Install perl-PerlIO-utf8_strict 0.007-2
Install perl-Pod-Coverage 0.23-4
Install perl-Pod-Escapes 1.07-3
Install perl-Probe-Perl 0.03-4
Install perl-Proc-ProcessTable 0.56-1
Install perl-Readonly 2.05-2
Install perl-Readonly-XS 1.05-5
Install perl-Regexp-Common 2017060201-2
Install perl-Role-Tiny 2.000006-1
Install perl-SGMLSpm 1.03ii-5
Install perl-SUPER 1.20141117-2
Install perl-Scalar-List-Utils 1.50-1
Install perl-Scope-Guard 0.21-2
Install perl-Socket 2.029-1
Install perl-Socket6 0.29-1
Install perl-Sort-Key 1.33-2
Install perl-Specio 0.43-1
Install perl-Spiffy 0.46-3
Install perl-Stow 2.2.2-2
Install perl-Sub-Exporter 0.987-4
Install perl-Sub-Exporter-Progressive 0.001013-2
Install perl-Sub-Identify 0.14-2
Install perl-Sub-Info 0.002-2
Install perl-Sub-Install 0.928-3
Install perl-Sub-Name 0.21-2
Install perl-Sub-Quote 2.006003-1
Install perl-Sub-Uplevel 0.2800-2
Install perl-Tee 0.14-6
Install perl-Term-ReadLine-Gnu 1.36-1
Install perl-Term-ReadLine-Perl 1.0303-6
Install perl-Term-Table 0.013-1
Install perl-TermReadKey 2.38-1
Install perl-Test-Base 0.89-1
Install perl-Test-CPAN-Meta 0.25-2
Install perl-Test-Deep 1.128-1
Install perl-Test-Differences 0.67-1
Install perl-Test-EOL 2.00-2
Install perl-Test-Exception 0.43-2
Install perl-Test-Fatal 0.014-3
Install perl-Test-File 1.443-1
Install perl-Test-File-ShareDir 1.001002-2
Install perl-Test-Harness 3.42-1
Install perl-Test-Inter 1.09-1
Install perl-Test-LeakTrace 0.16-2
Install perl-Test-MockModule 0.170.0-1
Install perl-Test-More-UTF8 0.05-1
Install perl-Test-Needs 0.002006-1
Install perl-Test-NoTabs 2.02-1
Install perl-Test-NoWarnings 1.04-5
Install perl-Test-Pod 1.52-1
Install perl-Test-Pod-Coverage 1.10-3
Install perl-Test-Reporter 1.62-3
Install perl-Test-Reporter-Transport-Metabase 1.999010-2
Install perl-Test-Requires 0.10-2
Install perl-Test-RequiresInternet 0.05-2
Install perl-Test-Script 1.25-1
Install perl-Test-Simple 1.302164-1
Install perl-Test-TrailingSpace 0.0301-2
Install perl-Test-Warn 0.36-1
Install perl-Test-Warnings 0.026-2
Install perl-Test-Without-Module 0.20-2
Install perl-Test-YAML 1.07-1
Install perl-Test-utf8 1.01-1
Install perl-Test2-Plugin-NoWarnings 0.07-1
Install perl-Test2-Suite 0.000120-1
Install perl-Text-BibTeX 0.88-1
Install perl-Text-CSV 1.99-1
Install perl-Text-CSV_XS 1.39-1
Install perl-Text-CharWidth 0.04-4
Install perl-Text-Diff 1.45-2
Install perl-Text-Glob 0.11-2
Install perl-Text-Roman 3.5-2
Install perl-Text-Template 1.55-1
Install perl-Text-WrapI18N 0.06-4
Install perl-Tie-Cycle 1.225-2
Install perl-TimeDate 2.30-3
Install perl-Tk 804.034-1
Install perl-Tk-Canvas-GradientColor 1.06-2
Install perl-Tk-ColoredButton 1.05-3
Install perl-Tk-EntryCheck 0.04-3
Install perl-Tk-Getopt 0.51-1
Install perl-Tk-Pod 0.9943-1
Install perl-Try-Tiny 0.30-1
Install perl-Types-Serialiser 1.0-4
Install perl-URI 1.76-1
Install perl-Unicode-Collate 1.27-1
Install perl-Unicode-LineBreak 2019.001-1
Install perl-User-Identity 0.99-1
Install perl-Variable-Magic 0.62-1
Install perl-WWW-Curl 4.17-3
Install perl-WWW-Curl-debuginfo 4.17-3
Install perl-WWW-RobotRules 6.02-6
Install perl-Win32-API 0.84-1
Install perl-Win32-GUI 1.14-1
Install perl-Wx 0.9932-1
Install perl-Wx-build 0.9932-1
Install perl-XML-DOM 1.46-2
Install perl-XML-LibXML 2.0134-2
Install perl-XML-LibXML-Simple 0.99-1
Install perl-XML-LibXSLT 1.96-1
Install perl-XML-NamespaceSupport 1.12-2
Install perl-XML-Parser 2.44-3
Install perl-XML-RegExp 0.04-3
Install perl-XML-SAX 1.00-1
Install perl-XML-SAX-Base 1.09-2
Install perl-XML-SAX-Expat 0.51-3
Install perl-XML-Simple 2.25-1
Install perl-XML-Stream 1.24-2
Install perl-XML-Writer 0.625-2
Install perl-XML-XPath 1.44-1
Install perl-Xfce4-Xfconf 4.12.0-2
Install perl-YAML 1.28-1
Install perl-YAML-LibYAML 0.77-1
Install perl-YAML-Tiny 1.73-1
Install perl-autovivification 0.18-1
Install perl-common-sense 3.74-2
Install perl-gdal 2.4.0-1
Install perl-gettext 1.07-2
Install perl-gv 2.40.1-4
Install perl-inc-latest 0.500-2
Install perl-libwww-perl 6.38-1
Install perl-libxml-perl 0.08-6
Install perl-marisa 0.2.4-4
Install perl-ming 0.4.8-3
Install perl-namespace-autoclean 0.28-2
Install perl-namespace-clean 0.27-2
Install perl-net-snmp 5.7.3-1
Install perl-openwsman 2.6.5-1
Install perl-zinnia 0.06-10
Install perl_autorebase 5.26.3-1
Install perl_base 5.26.3-1
Install perl_manpages 5.26.3-1
Install perl_pods 5.26.3-1
Install php 7.3.4-1
Install php-PEAR 1.10.9-1
Install php-bcmath 7.3.4-1
Install php-bz2 7.3.4-1
Install php-calendar 7.3.4-1
Install php-ctype 7.3.4-1
Install php-curl 7.3.4-1
Install php-dba 7.3.4-1
Install php-debuginfo 7.3.4-1
Install php-devel 7.3.4-1
Install php-enchant 7.3.4-1
Install php-exif 7.3.4-1
Install php-fileinfo 7.3.4-1
Install php-ftp 7.3.4-1
Install php-gd 7.3.4-1
Install php-gettext 7.3.4-1
Install php-gmp 7.3.4-1
Install php-gv 2.40.1-4
Install php-iconv 7.3.4-1
Install php-imap 7.3.4-1
Install php-intl 7.3.4-1
Install php-json 7.3.4-1
Install php-ldap 7.3.4-1
Install php-mbstring 7.3.4-1
Install php-ming 0.4.8-3
Install php-mysqli 7.3.4-1
Install php-odbc 7.3.4-1
Install php-opcache 7.3.4-1
Install php-pdo_dblib 7.3.4-1
Install php-pdo_mysql 7.3.4-1
Install php-pdo_odbc 7.3.4-1
Install php-pdo_pgsql 7.3.4-1
Install php-pdo_sqlite 7.3.4-1
Install php-pgsql 7.3.4-1
Install php-phar 7.3.4-1
Install php-posix 7.3.4-1
Install php-pspell 7.3.4-1
Install php-recode 7.3.4-1
Install php-shmop 7.3.4-1
Install php-simplexml 7.3.4-1
Install php-soap 7.3.4-1
Install php-sockets 7.3.4-1
Install php-sodium 7.3.4-1
Install php-sqlite3 7.3.4-1
Install php-sysvmsg 7.3.4-1
Install php-sysvsem 7.3.4-1
Install php-sysvshm 7.3.4-1
Install php-tidy 7.3.4-1
Install php-tokenizer 7.3.4-1
Install php-wddx 7.3.4-1
Install php-xmlreader 7.3.4-1
Install php-xmlrpc 7.3.4-1
Install php-xmlwriter 7.3.4-1
Install php-xsl 7.3.4-1
Install php-zip 7.3.4-1
Install php-zlib 7.3.4-1
Install pidgin 2.13.0-1
Install ping 1.9.4-1
Install pkg-config 1.6.0-1 (automatically added)
Install pkgconf 1.6.0-1 (automatically added)
Install planet 2.0-4
Install poppler-data 0.4.8-1
Install postgresql 11.2-1 (automatically added)
Install postgresql-client 11.2-1
Install postgresql-contrib 11.2-1
Install postgresql-devel 11.2-1
Install postgresql-doc 11.2-1
Install postgresql-plperl 11.2-1
Install postgresql-plpython 11.2-1
Install preview-latex 11.92-1 (automatically added)
Install pristine-tar 1.28-4
Install pstoedit 3.73-1 (automatically added)
Install publicsuffix-list-dafsa 20190419-1 (automatically added)
Install pulseaudio 11.1-1
Install pulseaudio-equalizer 11.1-1
Install pulseaudio-esound-compat 11.1-1 (automatically added)
Install pulseaudio-module-gconf 11.1-1 (automatically added)
Install pulseaudio-utils 11.1-1
Install pwget 2015.0927+git36776ae-1
Install pylint 1.3.1-1
Install python-beautifulsoup 3.2.1-1
Install python-configobj 5.0.6-1
Install python-egg 2.29.0-2
Install python-fastimport 0.9.2-2
Install python-feedparser 5.0.1-2
Install python-gdata 2.0.18-1
Install python-gi-devel 3.26.1-2
Install python-gobject 2.28.7-1 (automatically added)
Install python-gobject-common 2.28.7-1 (automatically added)
Install python-gtk2.0 2.24.0-3 (automatically added)
Install python-gtk2.0-doc 2.24.0-3
Install python-htmltmpl 1.22-3
Install python-lcms 1.19-5
Install python-libxslt 1.1.29-1 (automatically added)
Install python-logilab-astng 0.24.3-1 (automatically added)
Install python-logilab-common 1.3.0-1 (automatically added)
Install python-pip-wheel 19.0.3-1 (automatically added)
Install python-pynotify 0.1.1-5
Install python-pynotify-debuginfo 0.1.1-5
Install python-pypdf 1.13-2
Install python-pyqt5-common 5.9.2-1
Install python-setuptools-wheel 40.8.0-1 (automatically added)
Install python2 2.7.16-1 (automatically added)
Install python2-gobject 2.28.7-1 (automatically added)
Install python27 2.7.16-1 (automatically added)
Install python27-cairo 1.14.1-1 (automatically added)
Install python27-cffi 1.12.2-1 (automatically added)
Install python27-chardet 3.0.4-1 (automatically added)
Install python27-dbus 1.2.8-1 (automatically added)
Install python27-gi 3.26.1-2 (automatically added)
Install python27-imaging 5.4.1-1 (automatically added)
Install python27-ipaddress 1.0.22-1
Install python27-libxml2 2.9.9-2 (automatically added)
Install python27-numpy 1.16.2-1 (automatically added)
Install python27-olefile 0.46-1 (automatically added)
Install python27-ply 3.11-1 (automatically added)
Install python27-pycparser 2.19-1 (automatically added)
Install python27-pygments 2.3.1-1 (automatically added)
Install python27-reportlab 3.5.16-1 (automatically added)
Install python27-setuptools 40.8.0-1 (automatically added)
Install python27-six 1.12.0-1 (automatically added)
Install python3 3.6.8-1 (automatically added)
Install python3-speechd 0.8.7-1 (automatically added)
Install python36 3.6.8-1 (automatically added)
Install python36-cffi 1.12.2-1 (automatically added)
Install python36-chardet 3.0.4-1 (automatically added)
Install python36-imaging 5.4.1-1 (automatically added)
Install python36-isc 9.11.6-1 (automatically added)
Install python36-olefile 0.46-1 (automatically added)
Install python36-ply 3.11-1 (automatically added)
Install python36-pycparser 2.19-1 (automatically added)
Install python36-pygments 2.3.1-1 (automatically added)
Install python36-setuptools 40.8.0-1 (automatically added)
Install python36-xdg 0.26-1 (automatically added)
Install python37 3.7.3-1
Install python37-appdirs 1.4.3-2
Install python37-asn1crypto 0.24.0-1
Install python37-attrs 19.1.0-1
Install python37-automat 0.7.0-1 (automatically added)
Install python37-babel 2.6.0-1
Install python37-brotli 1.0.7-1
Install python37-bs4 4.7.1-1
Install python37-bugzilla 2.2.0-1
Install python37-cffi 1.12.2-1
Install python37-chardet 3.0.4-1
Install python37-clang 5.0.2-1
Install python37-constantly 15.1.0-2
Install python37-crypto 2.6.1-2
Install python37-cryptography 2.6.1-1
Install python37-cython 0.29.6-1
Install python37-decorator 4.4.0-1
Install python37-devel 3.7.3-1
Install python37-doc 3.7.3-1
Install python37-docutils 0.14-1
Install python37-dropbox 9.3.0-1
Install python37-enchant 1.6.11-2
Install python37-html5lib 1.0.1-1
Install python37-httplib2 0.11.3-1
Install python37-hyperlink 18.0.0-1
Install python37-idna 2.8-1
Install python37-imagesize 1.1.0-1
Install python37-imaging 5.4.1-1
Install python37-incremental 17.5.0-1
Install python37-ipython 5.8.0-1
Install python37-ipython_genutils 0.2.0-1 (automatically added)
Install python37-isc 9.11.6-1
Install python37-isodate 0.6.0-1
Install python37-libxml2 2.9.9-2
Install python37-lxml 4.3.2-1 (automatically added)
Install python37-mako 1.0.8-1
Install python37-marisa 0.2.4-4
Install python37-markupsafe 1.1.1-1
Install python37-mutagen 1.42.0-1
Install python37-nghttp2 1.37.0-1
Install python37-numpy 1.16.2-1 (automatically added)
Install python37-olefile 0.46-1
Install python37-openssl 19.0.0-1
Install python37-openwsman 2.6.5-1
Install python37-packaging 19.0-1
Install python37-pexpect 4.6.0-1
Install python37-pickleshare 0.7.5-1
Install python37-pip 19.0.3-1
Install python37-ply 3.11-1 (automatically added)
Install python37-prompt_toolkit 1.0.15-1
Install python37-ptyprocess 0.6.0-1
Install python37-pyasn1 0.4.5-1 (automatically added)
Install python37-pyasn1-modules 0.2.4-1 (automatically added)
Install python37-pycparser 2.19-1
Install python37-pygments 2.3.1-1
Install python37-pyparsing 2.3.1-1
Install python37-pytz 2018.9-2
Install python37-reportlab 3.5.16-1
Install python37-requests 2.21.0-1
Install python37-rsa 4.0-1
Install python37-service_identity 18.1.0-1
Install python37-setuptools 40.8.0-1
Install python37-simplegeneric 0.8.1-4
Install python37-simplejson 3.16.0-1
Install python37-six 1.12.0-1 (automatically added)
Install python37-sqlalchemy 1.3.1-1
Install python37-tkinter 3.7.3-1 (automatically added)
Install python37-traitlets 4.3.2-2
Install python37-twisted 18.9.0-1
Install python37-urllib3 1.24.1-1 (automatically added)
Install python37-wcwidth 0.1.7-1
Install python37-webencodings 0.5.1-2
Install python37-wheel 0.33.1-1
Install python37-whoosh 2.7.4-2
Install python37-yaml 3.13-1
Install python37-zope.interface 4.6.0-1 (automatically added)
Install qupzilla 1.8.9-3
Install rebase 4.4.4-1
Install recode 3.7-beta2-1 (automatically added)
Install rgb 1.0.5-1 (automatically added)
Install rpcbind 1.2.5-1 (automatically added)
Install rsh 0.17-2
Install rsh-server 0.17-2
Install rsnapshot 1.4.2-1
Install rsync 3.1.2-1
Install ruby 2.6.3-1
Install ruby-actioncable 5.1.6-1
Install ruby-actioncable-doc 5.1.6-1
Install ruby-actionmailer 5.1.6-1
Install ruby-actionmailer-doc 5.1.6-1
Install ruby-actionpack 5.1.6-1
Install ruby-actionpack-doc 5.1.6-1
Install ruby-actionview 5.1.6-1
Install ruby-actionview-doc 5.1.6-1
Install ruby-activejob 5.1.6-1
Install ruby-activejob-doc 5.1.6-1
Install ruby-activemodel 5.1.6-1
Install ruby-activemodel-doc 5.1.6-1
Install ruby-activerecord 5.1.6-1
Install ruby-activerecord-deprecated_finders 1.0.4-1
Install ruby-activerecord-deprecated_finders-doc 1.0.4-1
Install ruby-activerecord-doc 5.1.6-1
Install ruby-activesupport 5.1.6-1
Install ruby-activesupport-doc 5.1.6-1
Install ruby-arel 8.0.0-1
Install ruby-arel-doc 8.0.0-1
Install ruby-atk 3.2.9-1
Install ruby-atk-doc 3.2.9-1
Install ruby-bcrypt 3.1.12-1
Install ruby-bcrypt-doc 3.1.12-1
Install ruby-bindex 0.5.0-1
Install ruby-bindex-doc 0.5.0-1
Install ruby-binding_of_caller 0.8.0-1
Install ruby-binding_of_caller-doc 0.8.0-1
Install ruby-builder 3.2.3-1
Install ruby-builder-doc 3.2.3-1
Install ruby-byebug 11.0.1-1
Install ruby-byebug-doc 11.0.1-1
Install ruby-caca 0.99.beta19-4
Install ruby-cairo 1.14.6-3
Install ruby-cairo-devel 1.14.6-3
Install ruby-cairo-doc 1.14.6-3
Install ruby-cairo-gobject 3.2.9-1
Install ruby-cairo-gobject-devel 3.2.9-1
Install ruby-cairo-gobject-doc 3.2.9-1
Install ruby-clutter 3.2.9-1
Install ruby-clutter-doc 3.2.9-1
Install ruby-clutter-gdk 3.2.9-1
Install ruby-clutter-gdk-doc 3.2.9-1
Install ruby-clutter-gstreamer 3.2.9-1
Install ruby-clutter-gstreamer-doc 3.2.9-1
Install ruby-clutter-gtk 3.2.9-1
Install ruby-clutter-gtk-doc 3.2.9-1
Install ruby-coffee-rails 4.2.2-1
Install ruby-coffee-rails-doc 4.2.2-1
Install ruby-coffee-script 2.4.1-1
Install ruby-coffee-script-doc 2.4.1-1
Install ruby-coffee-script-source 1.10.0-1
Install ruby-coffee-script-source-doc 1.10.0-1
Install ruby-columnize 0.9.0-1
Install ruby-columnize-doc 0.9.0-1
Install ruby-concurrent-ruby 1.0.5-1
Install ruby-concurrent-ruby-doc 1.0.5-1
Install ruby-crass 1.0.4-1
Install ruby-crass-doc 1.0.4-1
Install ruby-curses 1.2.7-1
Install ruby-curses-doc 1.2.7-1
Install ruby-dbus 0.14.1-1
Install ruby-dbus-doc 0.14.1-1
Install ruby-debug_inspector 0.0.3-2
Install ruby-debug_inspector-doc 0.0.3-2
Install ruby-debuginfo 2.6.3-1
Install ruby-devel 2.6.3-1
Install ruby-did_you_mean 1.2.2-1
Install ruby-did_you_mean-doc 1.2.2-1
Install ruby-doc 2.6.3-1
Install ruby-erubi 1.7.1-1
Install ruby-erubi-doc 1.7.1-1
Install ruby-erubis 2.7.0-2
Install ruby-erubis-doc 2.7.0-2
Install ruby-execjs 2.5.2-1
Install ruby-execjs-doc 2.5.2-1
Install ruby-gdk3 3.2.9-1
Install ruby-gdk3-doc 3.2.9-1
Install ruby-gdk_pixbuf2 3.2.9-1
Install ruby-gdk_pixbuf2-doc 3.2.9-1
Install ruby-gettext 3.2.9-1
Install ruby-gettext-doc 3.2.9-1
Install ruby-gio2 3.2.9-1
Install ruby-gio2-devel 3.2.9-1
Install ruby-gio2-doc 3.2.9-1
Install ruby-glib2 3.2.9-1
Install ruby-glib2-devel 3.2.9-1
Install ruby-glib2-doc 3.2.9-1
Install ruby-globalid 0.4.1-1
Install ruby-globalid-doc 0.4.1-1
Install ruby-gobject-introspection 3.2.9-1
Install ruby-gobject-introspection-devel 3.2.9-1
Install ruby-gobject-introspection-doc 3.2.9-1
Install ruby-goocanvas1 1.2.6-5
Install ruby-goocanvas1-devel 1.2.6-5
Install ruby-goocanvas1-doc 1.2.6-5
Install ruby-goocanvas2 2.2.0-4
Install ruby-goocanvas2-devel 2.2.0-4
Install ruby-goocanvas2-doc 2.2.0-4
Install ruby-gstreamer1.0 3.2.9-1
Install ruby-gstreamer1.0-devel 3.2.9-1
Install ruby-gstreamer1.0-doc 3.2.9-1
Install ruby-gtk2 3.2.9-1
Install ruby-gtk2-devel 3.2.9-1
Install ruby-gtk2-doc 3.2.9-1
Install ruby-gtk3 3.2.9-1
Install ruby-gtk3-devel 3.2.9-1
Install ruby-gtk3-doc 3.2.9-1
Install ruby-gtksourceview2 3.2.9-1
Install ruby-gtksourceview2-devel 3.2.9-1
Install ruby-gtksourceview2-doc 3.2.9-1
Install ruby-gtksourceview3 3.2.9-1
Install ruby-gtksourceview3-doc 3.2.9-1
Install ruby-gv 2.40.1-4
Install ruby-hike 2.1.3-1
Install ruby-hike-doc 2.1.3-1
Install ruby-hitimes 1.3.1-1
Install ruby-hitimes-doc 1.3.1-1
Install ruby-hoe 3.17.2-1
Install ruby-hoe-doc 3.17.2-1
Install ruby-hpricot 0.8.6-6
Install ruby-hpricot-doc 0.8.6-6
Install ruby-htmlentities 4.3.4-1
Install ruby-htmlentities-doc 4.3.4-1
Install ruby-i18n 0.9.5-1
Install ruby-i18n-doc 0.9.5-1
Install ruby-imagesize 0.1.1-4
Install ruby-imagesize-doc 0.1.1-4
Install ruby-jbuilder 2.7.0-1
Install ruby-jbuilder-doc 2.7.0-1
Install ruby-journey 1.0.4-2
Install ruby-journey-doc 1.0.4-2
Install ruby-jquery-rails 4.3.3-1
Install ruby-jquery-rails-doc 4.3.3-1
Install ruby-kgio 2.11.2-1
Install ruby-kgio-doc 2.11.2-1
Install ruby-listen 3.0.8-1
Install ruby-listen-doc 3.0.8-1
Install ruby-locale 2.1.2-1
Install ruby-locale-doc 2.1.2-1
Install ruby-loofah 2.2.2-1
Install ruby-loofah-doc 2.2.2-1
Install ruby-mail 2.6.6-1
Install ruby-mail-doc 2.6.6-1
Install ruby-marc 0.7.1-1
Install ruby-marc-doc 0.7.1-1
Install ruby-marisa 0.2.4-4
Install ruby-method_source 0.9.2-1
Install ruby-method_source-doc 0.9.2-1
Install ruby-mime-types 3.1-1
Install ruby-mime-types-data 3.2016.0521-1
Install ruby-mime-types-data-doc 3.2016.0521-1
Install ruby-mime-types-doc 3.1-1
Install ruby-minitest 5.10.3-1
Install ruby-minitest-doc 5.10.3-1
Install ruby-molinillo 0.2.3-1
Install ruby-molinillo-doc 0.2.3-1
Install ruby-multi_json 1.13.1-1
Install ruby-multi_json-doc 1.13.1-1
Install ruby-mysql2 0.5.2-1
Install ruby-mysql2-debuginfo 0.5.2-1
Install ruby-mysql2-doc 0.5.2-1
Install ruby-native-package-installer 1.0.6-1
Install ruby-native-package-installer-doc 1.0.6-1
Install ruby-net-http-persistent 2.9.4-1
Install ruby-net-http-persistent-doc 2.9.4-1
Install ruby-net-telnet 0.2.0-1
Install ruby-net-telnet-doc 0.2.0-1
Install ruby-nio4r 2.3.1-1
Install ruby-nio4r-doc 2.3.1-1
Install ruby-nokogiri 1.10.3-1
Install ruby-nokogiri-doc 1.10.3-1
Install ruby-oj 3.7.12-1
Install ruby-oj-doc 3.7.12-1
Install ruby-openbabel 2.3.2-6
Install ruby-openwsman 2.6.5-1
Install ruby-pango 3.2.9-1
Install ruby-pango-devel 3.2.9-1
Install ruby-pango-doc 3.2.9-1
Install ruby-pg 1.1.4-1
Install ruby-pg-doc 1.1.4-1
Install ruby-pkg-config 1.3.7-1
Install ruby-pkg-config-doc 1.3.7-1
Install ruby-polyglot 0.3.5-1
Install ruby-polyglot-doc 0.3.5-1
Install ruby-poppler 3.2.9-1
Install ruby-poppler-doc 3.2.9-1
Install ruby-power_assert 1.1.4-1
Install ruby-power_assert-doc 1.1.4-1
Install ruby-puma 3.11.4-1
Install ruby-puma-doc 3.11.4-1
Install ruby-puppet-lint 2.3.5-1
Install ruby-puppet-lint-doc 2.3.5-1
Install ruby-racc 1.4.14-3
Install ruby-racc-doc 1.4.14-3
Install ruby-rack 2.0.6-1
Install ruby-rack-cache 1.7.1-1
Install ruby-rack-cache-doc 1.7.1-1
Install ruby-rack-doc 2.0.6-1
Install ruby-rack-ssl 1.4.1-1
Install ruby-rack-ssl-doc 1.4.1-1
Install ruby-rack-test 0.8.3-1
Install ruby-rack-test-doc 0.8.3-1
Install ruby-rails 5.1.6-1
Install ruby-rails-deprecated_sanitizer 1.0.3-1
Install ruby-rails-deprecated_sanitizer-doc 1.0.3-1
Install ruby-rails-doc 5.1.6-1
Install ruby-rails-dom-testing 2.0.3-1
Install ruby-rails-dom-testing-doc 2.0.3-1
Install ruby-rails-html-sanitizer 1.0.4-1
Install ruby-rails-html-sanitizer-doc 1.0.4-1
Install ruby-railties 5.1.6-1
Install ruby-railties-doc 5.1.6-1
Install ruby-raindrops 0.19.0-2
Install ruby-raindrops-doc 0.19.0-2
Install ruby-rake 12.3.2-1
Install ruby-rake-compiler 1.0.7-1
Install ruby-rake-compiler-doc 1.0.7-1
Install ruby-rake-doc 12.3.2-1
Install ruby-rdoc 6.1.1-1
Install ruby-rdoc-doc 6.1.1-1
Install ruby-rdtool 0.6.38-3
Install ruby-rdtool-doc 0.6.38-3
Install ruby-redcarpet 3.4.0-2
Install ruby-redcarpet-doc 3.4.0-2
Install ruby-redis 3.3.5-1
Install ruby-rsvg2 3.2.9-1
Install ruby-rsvg2-doc 3.2.9-1
Install ruby-sass 3.5.6-1
Install ruby-sass-doc 3.5.6-1
Install ruby-sass-listen 4.0.0-1
Install ruby-sass-listen-doc 4.0.0-1
Install ruby-sass-rails 5.0.7-1
Install ruby-sass-rails-doc 5.0.7-1
Install ruby-sdoc 0.4.2-1
Install ruby-sdoc-doc 0.4.2-1
Install ruby-solv 0.6.34-1
Install ruby-sprockets 3.7.1-1
Install ruby-sprockets-doc 3.7.1-1
Install ruby-sprockets-rails 3.2.1-1
Install ruby-sprockets-rails-doc 3.2.1-1
Install ruby-sqlite3 1.3.13-2
Install ruby-sqlite3-doc 1.3.13-2
Install ruby-syck 1.4.0-1
Install ruby-syck-doc 1.4.0-1
Install ruby-tcltk 2.6.3-1
Install ruby-test-unit 3.3.2-1
Install ruby-test-unit-doc 3.3.2-1
Install ruby-text 1.3.1-1
Install ruby-text-doc 1.3.1-1
Install ruby-thor 0.20.3-1
Install ruby-thor-doc 0.20.3-1
Install ruby-thread_safe 0.3.6-1
Install ruby-thread_safe-doc 0.3.6-1
Install ruby-tilt 2.0.8-1
Install ruby-tilt-doc 2.0.8-1
Install ruby-timers 4.3.0-1
Install ruby-timers-doc 4.3.0-1
Install ruby-tk 0.2.0-2
Install ruby-tk-doc 0.2.0-2
Install ruby-treetop 1.6.10-1
Install ruby-treetop-doc 1.6.10-1
Install ruby-turbolinks 5.2.0-1
Install ruby-turbolinks-doc 5.2.0-1
Install ruby-turbolinks-source 5.2.0-1
Install ruby-turbolinks-source-doc 5.2.0-1
Install ruby-tzinfo 1.2.5-1
Install ruby-tzinfo-doc 1.2.5-1
Install ruby-uglifier 3.1.13-1
Install ruby-uglifier-doc 3.1.13-1
Install ruby-unicorn 5.4.1-1
Install ruby-unicorn-doc 5.4.1-1
Install ruby-vte 3.2.9-1
Install ruby-vte-devel 3.2.9-1
Install ruby-vte-doc 3.2.9-1
Install ruby-vte3 3.2.9-1
Install ruby-vte3-doc 3.2.9-1
Install ruby-web-console 3.6.2-1
Install ruby-web-console-doc 3.6.2-1
Install ruby-webkit-gtk 3.2.9-1
Install ruby-webkit-gtk-doc 3.2.9-1
Install ruby-webkit-gtk2 3.2.9-1
Install ruby-webkit-gtk2-doc 3.2.9-1
Install ruby-websocket-driver 0.6.5-2
Install ruby-websocket-driver-debuginfo 0.6.5-2
Install ruby-websocket-driver-doc 0.6.5-2
Install ruby-websocket-extensions 0.1.3-1
Install ruby-websocket-extensions-doc 0.1.3-1
Install ruby-xapian 1.4.5-3
Install ruby-xmlrpc 0.3.0-1
Install ruby-xmlrpc-doc 0.3.0-1
Install ruby-yajl 1.4.1-1
Install ruby-yajl-doc 1.4.1-1
Install ruby-zinnia 0.06-10
Install ruby-zoom 0.5.0-3
Install ruby-zoom-debuginfo 0.5.0-3
Install ruby-zoom-doc 0.5.0-3
Install rubygems 3.0.3-1
Install rubygems-doc 3.0.3-1
Install run 1.3.4-2
Install scintilla-win32 3.6.6-1 (automatically added)
Install scons 2.4.0-1
Install scribus 1.4.6-4
Install sed 4.4-1
Install sendxmpp 1.24-1
Install sgml-common 0.6.3-3 (automatically added)
Install shared-mime-info 1.8-1 (automatically added)
Install sharutils 4.15.2-1
Install sic 1.0-1
Install signify 1.14-1
Install sitecopy 0.16.6-2
Install snownews 1.5.12-1
Install sound-theme-freedesktop 0.8-1 (automatically added)
Install source-highlight 3.1.8-6 (automatically added)
Install speech-dispatcher 0.8.7-1
Install speech-dispatcher-utils 0.8.7-1
Install speexdsp 1.2-0.1.rc3 (automatically added)
Install squid 3.3.3-2
Install ssh-pageant 1.4-1
Install stow 2.2.2-2
Install stow-src 2.2.2-2 (source)
Install subversion 1.11.1-1 (automatically added)
Install subversion-httpd 1.11.1-1
Install subversion-ruby 1.11.1-1
Install suite3270 3.3.15ga9-1 (automatically added)
Install suomi-malaga 1.19-1 (automatically added)
Install syslog-ng 3.2.5-2
Install syslog-ng-src 3.2.5-2 (source)
Install t1lib5 5.1.2-13 (automatically added)
Install t1utils 1.39-1 (automatically added)
Install tailor 0.9.35+darcs20090615-2
Install tar 1.29-1
Install tar-debuginfo 1.29-1
Install tcl 8.6.8-1 (automatically added)
Install tcl-tix 8.4.3-3 (automatically added)
Install tcl-tk 8.6.8-1 (automatically added)
Install tdb 1.2.11-2
Install ted 2.23-3
Install terminfo 6.0-12.20171125
Install texinfo 6.6-1
Install texinfo-tex 6.6-1
Install texlive 20190509-1
Install texlive-collection-basic 20190509-1
Install texlive-collection-basic-doc 20190509-1
Install texlive-collection-bibtexextra 20190509-1
Install texlive-collection-bibtexextra-doc 20190509-1
Install texlive-collection-binextra 20190509-1
Install texlive-collection-binextra-doc 20190509-1
Install texlive-collection-context 20190509-1
Install texlive-collection-context-doc 20190509-1
Install texlive-collection-fontsextra 20190509-1
Install texlive-collection-fontsextra-doc 20190509-1
Install texlive-collection-fontsrecommended 20190509-1
Install texlive-collection-fontsrecommended-doc 20190509-1
Install texlive-collection-fontutils 20190509-1
Install texlive-collection-fontutils-doc 20190509-1
Install texlive-collection-formatsextra 20190509-1
Install texlive-collection-games 20190509-1
Install texlive-collection-humanities 20190509-1
Install texlive-collection-humanities-doc 20190509-1
Install texlive-collection-langarabic 20190509-1
Install texlive-collection-langchinese 20190509-1
Install texlive-collection-langcjk 20190509-1
Install texlive-collection-langcyrillic 20190509-1
Install texlive-collection-langczechslovak 20190509-1
Install texlive-collection-langenglish 20190509-1
Install texlive-collection-langeuropean 20190509-1
Install texlive-collection-langfrench 20190509-1
Install texlive-collection-langgerman 20190509-1
Install texlive-collection-langgreek 20190509-1
Install texlive-collection-langitalian 20190509-1
Install texlive-collection-langjapanese 20190509-1
Install texlive-collection-langkorean 20190509-1
Install texlive-collection-langother 20190509-1
Install texlive-collection-langpolish 20190509-1
Install texlive-collection-langportuguese 20190509-1
Install texlive-collection-langspanish 20190509-1
Install texlive-collection-latex 20190509-1
Install texlive-collection-latex-doc 20190509-1
Install texlive-collection-latexextra 20190509-1
Install texlive-collection-latexextra-doc 20190509-1
Install texlive-collection-latexrecommended 20190509-1
Install texlive-collection-latexrecommended-doc 20190509-1
Install texlive-collection-luatex 20190509-1
Install texlive-collection-luatex-doc 20190509-1
Install texlive-collection-mathscience 20190509-1
Install texlive-collection-mathscience-doc 20190509-1
Install texlive-collection-metapost 20190509-1
Install texlive-collection-metapost-doc 20190509-1
Install texlive-collection-music 20190509-1
Install texlive-collection-music-doc 20190509-1
Install texlive-collection-pictures 20190509-1
Install texlive-collection-pictures-doc 20190509-1
Install texlive-collection-plaingeneric 20190509-1
Install texlive-collection-plaingeneric-doc 20190509-1
Install texlive-collection-pstricks 20190509-1
Install texlive-collection-pstricks-doc 20190509-1
Install texlive-collection-publishers 20190509-1
Install texlive-collection-publishers-doc 20190509-1
Install texlive-collection-xetex 20190509-1
Install texlive-collection-xetex-doc 20190509-1
Install tidy 20090325-1
Install tin 2.4.3-1
Install tnef 1.4.9-1
Install transfig 3.2.7-1 (automatically added)
Install transmission 2.93-2
Install transmission-gtk 2.93-2
Install ttf2pt1 3.4.4-1 (automatically added)
Install tzcode 2018i-1
Install tzdata 2018i-1
Install uchardet 0.0.6-1
Install unbound 1.6.2-1
Install unfs3 0.9.23-0.1.20151008git
Install unicode-cldr-emoji-annotation 30.0.3-1
Install unzip 6.0-17
Install urlgrabber 3.1.0-3
Install urw-base35-fonts 20170801-5 (automatically added)
Install urw-base35-fonts-legacy 20170801-5 (automatically added)
Install util-linux 2.33.1-1
Install vcdimager 2.0.1-1
Install vim-minimal 8.1.1240-1
Install w32api-headers 5.0.4-1 (automatically added)
Install w32api-runtime 5.0.4-1 (automatically added)
Install w3m 0.5.3-3
Install webcheck 1.10.4-1
Install weechat 2.4-1
Install weechat-doc 2.4-1
Install weechat-guile 2.4-1
Install weechat-lua 2.4-1
Install weechat-perl 2.4-1
Install weechat-php 2.4-1
Install weechat-python 2.4-1
Install weechat-ruby 2.4-1
Install weechat-tcl 2.4-1
Install wget 1.19.1-2
Install wget-debuginfo 1.19.1-2
Install which 2.20-2
Install windows-default-manifest 6.4-1 (automatically added)
Install wordview 0.95-1
Install wput 0.6.2+git20130413-1
Install writerperfect 0.9.6-1
Install wtf 0.0.4-8
Install wv 1.2.9-2
Install x3270 3.3.15ga9-1
Install xarchiver 0.5.4-1
Install xbitmaps 1.1.1-1 (automatically added)
Install xchm 1.23-1
Install xdelta 1.1.4-2 (automatically added)
Install xdg-utils 1.1.1-2 (automatically added)
Install xfconfd 4.12.0-2 (automatically added)
Install xgraph 12.1-5
Install xhtml2ps 1.0b7-2
Install xkbcomp 1.4.0-1 (automatically added)
Install xkeyboard-config 2.23.1-1 (automatically added)
Install xlsx2csv 0.11+20120814+gitf54ab78-2
Install xmlto 0.0.26-1
Install xmp 4.1.0-1
Install xorg-x11-fonts-dpi75 7.5-3 (automatically added)
Install xorgproto 2018.4-1 (automatically added)
Install xz 5.2.3-1
Install yajl 2.1.0-1
Install yelp-tools 3.18.0-1 (automatically added)
Install yelp-xsl 3.20.1-1 (automatically added)
Install zip 3.0-12
Install zlib-devel 1.2.11-1 (automatically added)
Install zlib0 1.2.11-1
Install znc 1.7.2-1 (automatically added)
Install znc-perl 1.7.2-1
Install znc-python 1.7.2-1
Install zpaq 7.15-1
