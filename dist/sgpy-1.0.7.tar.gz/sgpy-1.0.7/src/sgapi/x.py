import requests

print('Hello, World!')